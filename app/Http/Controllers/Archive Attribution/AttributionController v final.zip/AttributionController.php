<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Attribution;
use App\Models\Coursier;
use App\Models\Pli;
use App\Models\PliStatuerHistory;
use App\Models\Statuer;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AttributionController extends Controller
{



        //     public function index()
        // {
        //     //  Plis non attribués
        //     $plies = Pli::whereDoesntHave('attributions', function ($query) {
        //         $query->whereNotNull('coursier_ramassage_id')
        //             ->orWhereNotNull('coursier_depot_id');
        //     })->get();

        //     //  Plis attribués au ramassage
        //     $plisRamassageList = Pli::whereHas('attributions', function ($query) {
        //         $query->whereNotNull('coursier_ramassage_id');
        //     })->get();

        //     //  Plis attribués au dépôt
        //     $plisDepotList = Pli::whereHas('attributions', function ($query) {
        //         $query->whereNotNull('coursier_depot_id');
        //     })->get();

        //     //  Tous les plis attribués avec pagination
        //     $plisAttribuesList = Pli::whereHas('attributions')->paginate(10);

        //     //  Ajout des dates d'attribution aux plis
        //     // foreach ($plies as $pli) {
        //     //     $pli->date_attribution_ramassage = optional($pli->attributions->whereNotNull('date_ramassage')->first())->date_ramassage;
        //     //     $pli->date_attribution_depot = optional($pli->attributions->whereNotNull('date_depot')->first())->date_depot;
        //     // }

        //     $plies = $plies->map(function ($pli) {
        //         $pli->date_attribution_ramassage = optional($pli->attributions->whereNotNull('date_ramassage')->first())->date_ramassage;
        //         $pli->date_attribution_depot = optional($pli->attributions->whereNotNull('date_depot')->first())->date_depot;
        //         return $pli;
        //     });

        //      // Récupérer tous les coursiers
        //     $coursiers = Coursier::all();



        //           //Compte des plis

        //     // Décompte des plis
        //     $plisNonAttribues = Pli::whereDoesntHave('attributions', function ($query) {
        //         $query->whereNotNull('coursier_ramassage_id')
        //             ->orWhereNotNull('coursier_depot_id');
        //     })->count();

        //     $plisRamassage = Pli::whereHas('attributions', function ($query) {
        //         $query->whereNotNull('coursier_ramassage_id');
        //     })->count();

        //     $plisDepot = Pli::whereHas('attributions', function ($query) {
        //         $query->whereNotNull('coursier_depot_id');
        //     })->count();

        //       // Nouveau : Plis traités (attribués au ramassage et au dépôt)
        //     $plisTraites = Pli::whereHas('attributions', function ($query) {
        //         $query->whereNotNull('coursier_ramassage_id')
        //             ->whereNotNull('coursier_depot_id');
        //     })->count();

        //     // Passage des variables à la vue
        //     // return view('admin.attributions.index', compact('plisNonAttribues', 'plisRamassage', 'plisDepot'));

        //     //  Retour unique de la vue avec toutes les variables nécessaires
        //     return view('admin.attributions.index', compact('plies', 'plisRamassageList', 'plisDepotList', 'plisAttribuesList','plisNonAttribues', 'plisRamassage', 'plisDepot','plisTraites','coursiers'));

        // }




        // public function index()
        //     {
        //         //  Récupérer les zones des expéditeurs et des destinataires des plis non attribués
        //         $zonesExpediteurs = Pli::pluck('user_zone')->unique()->filter(function ($zone) {
        //             return !is_null($zone) && $zone !== '000'; // Exclure "000" et NULL
        //         });

        //         $zonesDestinataires = Pli::pluck('destinataire_zone')->unique()->filter(function ($zone) {
        //             return !is_null($zone) && $zone !== '000'; // Exclure "000" et NULL
        //         });

        //         //  Sélectionner les coursiers qui couvrent les zones des expéditeurs et destinataires
        //         $coursiersDisponibles = Coursier::where(function ($query) use ($zonesExpediteurs, $zonesDestinataires) {
        //             if ($zonesExpediteurs->isNotEmpty()) {
        //                 $query->whereIn('zones', $zonesExpediteurs);
        //             }
        //             if ($zonesDestinataires->isNotEmpty()) {
        //                 $query->orWhereIn('zones', $zonesDestinataires);
        //             }
        //         })->get();

        //         //  Sélectionner TOUS les coursiers comme alternative
        //         $coursiersAlternatifs = Coursier::all();

        //         //  Récupérer les plis et leurs attributions
        //         $plies = Pli::whereDoesntHave('attributions', function ($query) {
        //             $query->whereNotNull('coursier_ramassage_id')
        //                 ->orWhereNotNull('coursier_depot_id');
        //         })->get();

        //         $plisRamassageList = Pli::whereHas('attributions', function ($query) {
        //             $query->whereNotNull('coursier_ramassage_id');
        //         })->get();

        //         $plisDepotList = Pli::whereHas('attributions', function ($query) {
        //             $query->whereNotNull('coursier_depot_id');
        //         })->get();

        //         $plisAttribuesList = Pli::whereHas('attributions')->paginate(10);

        //         // Ajout des dates d'attribution aux plis
        //         $plies = $plies->map(function ($pli) {
        //             $pli->date_attribution_ramassage = optional($pli->attributions->whereNotNull('date_ramassage')->first())->date_ramassage;
        //             $pli->date_attribution_depot = optional($pli->attributions->whereNotNull('date_depot')->first())->date_depot;
        //             return $pli;
        //         });

        //         //  Décompte des plis pour les statistiques
        //         $plisNonAttribues = Pli::whereDoesntHave('attributions', function ($query) {
        //             $query->whereNotNull('coursier_ramassage_id')
        //                 ->orWhereNotNull('coursier_depot_id');
        //         })->count();

        //         $plisRamassage = Pli::whereHas('attributions', function ($query) {
        //             $query->whereNotNull('coursier_ramassage_id');
        //         })->count();

        //         $plisDepot = Pli::whereHas('attributions', function ($query) {
        //             $query->whereNotNull('coursier_depot_id');
        //         })->count();

        //         $plisTraites = Pli::whereHas('attributions', function ($query) {
        //             $query->whereNotNull('coursier_ramassage_id')
        //                 ->whereNotNull('coursier_depot_id');
        //         })->count();

        //                         //  Ajouter le téléphone des coursiers
        //         $coursiersDisponibles = Coursier::where(function ($query) use ($zonesExpediteurs, $zonesDestinataires) {
        //             if ($zonesExpediteurs->isNotEmpty()) {
        //                 $query->whereIn('zones', $zonesExpediteurs);
        //             }
        //             if ($zonesDestinataires->isNotEmpty()) {
        //                 $query->orWhereIn('zones', $zonesDestinataires);
        //             }
        //         })->get(['id', 'nom', 'prenoms', 'zones', 'telephone']); // 🔥 Ajout du téléphone

        //         $coursiersAlternatifs = Coursier::all(['id', 'nom', 'prenoms', 'zones', 'telephone']); // 🔥 Ajout du téléphone

        //         //  Récupérer le nombre de livraisons attribuées pour chaque coursier
        //         $coursiersDisponibles = $coursiersDisponibles->map(function ($coursier) {
        //             $coursier->nombre_plis_attribues = Attribution::where('coursier_ramassage_id', $coursier->id)
        //                                         ->orWhere('coursier_depot_id', $coursier->id)
        //                                         ->count();
        //             return $coursier;
        //         });

        //         $coursiersAlternatifs = $coursiersAlternatifs->map(function ($coursier) {
        //             $coursier->nombre_plis_attribues = Attribution::where('coursier_ramassage_id', $coursier->id)
        //                                         ->orWhere('coursier_depot_id', $coursier->id)
        //                                         ->count();
        //             return $coursier;
        //         });

        //         $nombreCoursiers = Coursier::count();


        //         //  Envoyer toutes les données à la vue
        //         return view('admin.attributions.index', compact(
        //             'plies', 'plisRamassageList', 'plisDepotList', 'plisAttribuesList',
        //             'plisNonAttribues', 'plisRamassage', 'plisDepot', 'plisTraites',
        //             'coursiersDisponibles', 'coursiersAlternatifs','coursiersDisponibles',
        //             'coursiersAlternatifs','nombreCoursiers'
        //         ));
        //     }
// La fonction index ici
public function index()
{
    // 🔹 Récupérer les zones des expéditeurs et des destinataires des plis non attribués
    $zonesExpediteurs = Pli::pluck('user_zone')->unique()->filter(fn($zone) => !is_null($zone) && $zone !== '000') ?? collect([]);
    $zonesDestinataires = Pli::pluck('destinataire_zone')->unique()->filter(fn($zone) => !is_null($zone) && $zone !== '000') ?? collect([]);

    // 🔹 Sélectionner les coursiers disponibles
    $coursiersDisponibles = Coursier::where(function ($query) use ($zonesExpediteurs, $zonesDestinataires) {
        if ($zonesExpediteurs->isNotEmpty()) {
            $query->whereIn('zones', $zonesExpediteurs);
        }
        if ($zonesDestinataires->isNotEmpty()) {
            $query->orWhereIn('zones', $zonesDestinataires);
        }
    })->get(['id', 'nom', 'prenoms', 'zones', 'telephone']) ?? collect([]);

    // 🔹 Sélectionner TOUS les coursiers comme alternative
    $coursiersAlternatifs = Coursier::all(['id', 'nom', 'prenoms', 'zones', 'telephone']) ?? collect([]);

    // 🔹 Récupérer les plis non attribués
    $plies = Pli::whereDoesntHave('attributions')->get() ?? collect([]);

    $plisRamassageList = Pli::whereHas('attributions', function ($query) {
        $query->whereNotNull('coursier_ramassage_id');
    })->get() ?? collect([]);

    $plisDepotList = Pli::whereHas('attributions', function ($query) {
        $query->whereNotNull('coursier_depot_id');
    })->get() ?? collect([]);

    $plisAttribuesList = Pli::whereHas('attributions')->paginate(10) ?? collect([]);

    // 🔹 Ajout des dates d'attribution aux plis
    $plies = $plies->map(function ($pli) {
        $pli->date_attribution_ramassage = optional($pli->attributions->whereNotNull('date_ramassage')->first())->date_ramassage ?? 'Non attribué';
        $pli->date_attribution_depot = optional($pli->attributions->whereNotNull('date_depot')->first())->date_depot ?? 'Non attribué';
        return $pli;
    });

    // 🔹 Décompte des plis
    $plisNonAttribues = Pli::whereDoesntHave('attributions')->count() ?? 0;
    $plisRamassage = Pli::whereHas('attributions', function ($query) {
        $query->whereNotNull('coursier_ramassage_id');
    })->count() ?? 0;

    $plisDepot = Pli::whereHas('attributions', function ($query) {
        $query->whereNotNull('coursier_depot_id');
    })->count() ?? 0;

    $plisTraites = Pli::whereHas('attributions', function ($query) {
        $query->whereNotNull('coursier_ramassage_id')->whereNotNull('coursier_depot_id');
    })->count() ?? 0;

    // 🔹 Ajout du nombre de livraisons attribuées pour chaque coursier
    $coursiersDisponibles = $coursiersDisponibles->map(function ($coursier) {
        $coursier->nombre_plis_attribues = Attribution::where('coursier_ramassage_id', $coursier->id)
            ->orWhere('coursier_depot_id', $coursier->id)
            ->count() ?? 0;
        return $coursier;
    });

    $coursiersAlternatifs = $coursiersAlternatifs->map(function ($coursier) {
        $coursier->nombre_plis_attribues = Attribution::where('coursier_ramassage_id', $coursier->id)
            ->orWhere('coursier_depot_id', $coursier->id)
            ->count() ?? 0;
        return $coursier;
    });

    $nombreCoursiers = Coursier::count() ?? 0;

    // 🔥 Envoi des données à la vue
    return view('admin.attributions.index', compact(
        'plies', 'plisRamassageList', 'plisDepotList', 'plisAttribuesList',
        'plisNonAttribues', 'plisRamassage', 'plisDepot', 'plisTraites',
        'coursiersDisponibles', 'coursiersAlternatifs', 'nombreCoursiers'
    ));
}





//Fin de la fonction index

        public function selectionnerCoursiersDisponibles()
        {
            // 1️⃣ Récupérer les zones des expéditeurs et des destinataires des plis non attribués
            $zonesExpediteurs = Pli::pluck('user_zone')->unique()->filter(function ($zone) {
                return !is_null($zone) && $zone !== '000'; // On exclut les valeurs "000" et NULL
            });

            $zonesDestinataires = Pli::pluck('destinataire_zone')->unique()->filter(function ($zone) {
                return !is_null($zone) && $zone !== '000'; // On exclut les valeurs "000" et NULL
            });

            // 2️⃣ Sélectionner les coursiers dont la zone correspond à l'une des deux
            $coursiersDisponibles = Coursier::where(function ($query) use ($zonesExpediteurs, $zonesDestinataires) {
                if ($zonesExpediteurs->isNotEmpty()) {
                    $query->whereIn('zones', $zonesExpediteurs);
                }
                if ($zonesDestinataires->isNotEmpty()) {
                    $query->orWhereIn('zones', $zonesDestinataires);
                }
            })->get();

            // 3️⃣ Sélectionner TOUS les coursiers comme alternative
            $coursiersAlternatifs = Coursier::all();

            // 4️⃣ Envoyer les données à la vue
            return view('admin.attributions.index', compact('coursiersDisponibles', 'coursiersAlternatifs'));
        }






        // Debut test attribuer groupe

        // public function attribuerEnGroupe(Request $request)
        // {
        //     $request->validate([
        //         'plies' => 'required|array',
        //         'coursier_id' => 'required|exists:coursiers,id',
        //         'type' => 'required|in:ramassage,depot',
        //     ]);

        //     foreach ($request->plies as $pliId) {
        //         $pli = Pli::findOrFail($pliId);

        //         // Attribution selon le type choisi
        //         if ($request->type === 'ramassage') {
        //             $pli->attributions()->create([
        //                 'coursier_ramassage_id' => $request->coursier_id,
        //             ]);
        //         } elseif ($request->type === 'depot') {
        //             $pli->attributions()->create([
        //                 'coursier_depot_id' => $request->coursier_id,
        //             ]);
        //         }
        //     }

        //     return back()->with('success', 'Plis attribués avec succès !');
        // }

        public function attribuerEnGroupe(Request $request)
        {
            $request->validate([
                'plies' => 'required|array',
                'coursier_id' => 'required|exists:coursiers,id',
                'type' => 'required|in:ramassage,depot',
            ]);

            foreach ($request->plies as $pliId) {
                $pli = Pli::findOrFail($pliId);

                // Attribution selon le type choisi avec la date d’attribution
                if ($request->type === 'ramassage') {
                    $pli->attributions()->create([
                        'coursier_ramassage_id' => $request->coursier_id,
                        'date_attribution_ramassage' => Carbon::today(), // 🔥 Ajout de la date sans heure
                    ]);
                } elseif ($request->type === 'depot') {
                    $pli->attributions()->create([
                        'coursier_depot_id' => $request->coursier_id,
                        'date_attribution_depot' => Carbon::today(), // 🔥 Ajout de la date sans heure
                    ]);
                }
            }

            return back()->with('success', 'Plis attribués avec succès !');
        }




         // Debut test attribuer groupe fin


        //Test Attribuer groupe



    // Attribuer un pli à un coursier pour le ramassage ou le dépôt ---------------------------------

    public function attribuerPli($pliId, Request $request)
    {
        $pli = Pli::find($pliId);   //Ecoute va recherche le id du pli
        if (!$pli) {
            return redirect()->route('admin.attributions.index')->with('error', 'Pli non trouvé'); // Si tu n'as pas troubvé retourne pli non trouveé
        }

        // Type d'attribution : ramassage ou dépôt
        $type = $request->input('type');
        if (!in_array($type, ['ramassage', 'depot'])) {
            return redirect()->route('admin.attributions.index')->with('error', 'Type d\'attribution invalide');
        }

        // Vérifier si une attribution existe déjà pour ce pli avec le même type
        $existingAttribution = Attribution::where('pli_id', $pli->id)
                                          ->where(function ($query) use ($type) {
                                              if ($type == 'ramassage') {
                                                  $query->whereNotNull('coursier_ramassage_id');
                                              } else {
                                                  $query->whereNotNull('coursier_depot_id');
                                              }
                                          })
                                          ->exists();

                    if ($existingAttribution) {
                        return redirect()->route('admin.attributions.index')->with('error', "Le pli a déjà été attribué pour le type $type.");
                    }

                    // Déterminer la zone en fonction du type d'attribution
                    $zone = ($type == 'ramassage') ? $pli->user_Zone : $pli->destinataire_zone;

                    // Rechercher des coursiers disponibles dans la zone spécifique
                $coursiers = Coursier::all()->filter(function ($coursier) use ($zone) {
                $zonesCoursier = is_array($coursier->zones) ? $coursier->zones : explode(',', $coursier->zones);
                return in_array($zone, $zonesCoursier);
            });

        // Vérifier si des coursiers sont disponibles dans la zone
        if ($coursiers->isEmpty()) {
            // Si aucun coursier disponible dans la zone, récupérer tous les autres coursiers
            $coursiers = Coursier::whereRaw("NOT FIND_IN_SET(?, zones)", [$zone])->get();

            if ($coursiers->isEmpty()) {
                return redirect()->route('admin.attributions.index')
                    ->with('error', 'Aucun coursier disponible pour l\'attribution.');
            }

            // Afficher un message d'avertissement pour l'utilisateur
            return view('admin.attributions.alternative', compact('pli', 'type', 'coursiers'));
        }

        // Sélectionner un coursier dans la zone, s'il y en a
        $coursier = $coursiers->first();

        // Créer ou récupérer une attribution pour le pli
        $attribution = Attribution::firstOrNew(['pli_id' => $pli->id]);

        // Affecter le coursier au ramassage ou au dépôt
      if($attribution)
        {
            if ($type =='ramassage') {
                $attribution->coursier_ramassage_id = $coursier->id;
                $attribution->date_attribution_ramassage = Carbon::now();  // Enregistrer la date d'attribution du ramassage
            } else {
                $attribution->coursier_depot_id = $coursier->id;
                $attribution->date_attribution_depot = Carbon::now();  // Enregistrer la date d'attribution du dépôt
            }
        }

        else{
            return redirect()->route('admin.attributions.index')->with('success', "Echec: Nous avons rencontré un probleme technique $type.");

        }




        // Sauvegarder l'attribution
        $attribution->save();

        return redirect()->route('admin.attributions.index')->with('success', "Pli attribué avec succès pour le $type.");
    }



    public function confirmerAttribution($pliId, $type, Request $request)
    {
        //  Vérification du pli
        $pli = Pli::find($pliId);
        if (!$pli) {
            return redirect()->route('admin.attributions.index')->with('error', 'Pli non trouvé.');
        }

        //  Vérification du coursier sélectionné
        $coursierId = $request->input('coursier_id');
        if (!$coursierId) {
            return redirect()->route('admin.attributions.index')->with('error', 'Aucun coursier sélectionné.');
        }

        //  Vérification si le pli est déjà attribué
        if (Attribution::where('pli_id', $pli->id)->exists()) {
            return redirect()->route('admin.attributions.index')->with('error', "Ce pli est déjà attribué au type :'$type'.");
        }

        //  Vérification du type d’attribution (Empêche les erreurs)
        if (!in_array($type, ['ramassage', 'depot'])) {
            return redirect()->route('admin.attributions.index')->with('error', "Erreur inconnue : Type '$type' invalide.");
        }

        //  Création d'une nouvelle attribution
        $attribution = new Attribution();
        $attribution->pli_id = $pli->id;

        //  Attribution du coursier selon le type
        if ($type == 'ramassage') {
            $attribution->coursier_ramassage_id = $coursierId;
            $attribution->date_attribution_ramassage = Carbon::now();

        } else { // Ici, `$type === 'depot'` est assuré
            $attribution->coursier_depot_id = $coursierId;
            $attribution->date_attribution_depot = Carbon::now();
        }

        //  Sauvegarde de l’attribution
        $attribution->save();
        $attribution->refresh(); // Recharge les nouvelles valeurs après l’enregistrement


        //  Redirection avec message de succès
        return redirect()->route('admin.attributions.index')->with('success', "Pli attribué avec succès pour le type '$type'.");
    }



        //     public function getCoursiersDisponibles($pliId, $type)
        // {
        //     $pli = Pli::findOrFail($pliId);

        //     // Définir la zone concernée
        //     $zone = ($type === 'ramassage') ? $pli->user->Zone : $pli->destinataire->zone;

        //     // Récupérer les coursiers qui gèrent cette zone
        //     $coursiers = Coursier::whereJsonContains('zones_gerees', $zone)->get();

        //     // Ajouter le nombre de coursiers disponibles par zone
        //     $zonesDispo = Coursier::selectRaw('zones_gerees, COUNT(*) as nombre')
        //                         ->whereJsonContains('zones_gerees', $zone)
        //                         ->groupBy('zones_gerees')
        //                         ->get();

        //     return response()->json(['coursiers' => $coursiers, 'zonesDispo' => $zonesDispo]);
        // }






// -------------------------------------------------------------------------------------------------
    //  / Fin de la fonction d'attribution des pli

public function impression(Request $request)
{
    // Récupérer tous les coursiers
    $coursiers = Coursier::all();

    // Requête de base pour récupérer les plis ayant une attribution de ramassage et le statut "en attente"
    $plisQuery = Pli::whereHas('attributions', function ($query) {
        $query->whereNotNull('coursier_ramassage_id');
    })
    ->whereHas('statuerHistories', function ($query) {
        $query->where('statuer_id', 1)
              ->whereRaw('pli_statuer_history.id = (
                  SELECT MAX(id)
                  FROM pli_statuer_history AS subquery
                  WHERE subquery.pli_id = pli_statuer_history.pli_id
              )');
    });

    // Appliquer le filtre si un coursier est sélectionné
    if ($request->has('coursier_id') && $request->input('coursier_id') != '') {
        $plisQuery->whereHas('attributions', function ($query) use ($request) {
            $query->where('coursier_ramassage_id', $request->input('coursier_id'));
        });
    }

    // Récupérer les plis filtrés
    $plis = $plisQuery->get();

    // Passer les plis et les coursiers à la vue
    return view('admin.attributions.impression', compact('plis', 'coursiers'));
}



public function filtrerParCoursierDepot(Request $request)
{
    // Récupérer tous les coursiers
    $coursiers = Coursier::all();

    // Requête de base pour récupérer les plis ayant une attribution de ramassage et le statut "en attente"
    $plisQuery = Pli::whereHas('attributions', function ($query) {
        $query->whereNotNull('coursier_depot_id');
    })
    ->whereHas('statuerHistories', function ($query) {
        $query->where('statuer_id', 2)
              ->whereRaw('pli_statuer_history.id = (
                  SELECT MAX(id)
                  FROM pli_statuer_history AS subquery
                  WHERE subquery.pli_id = pli_statuer_history.pli_id
              )');
    });

    // Appliquer le filtre si un coursier est sélectionné
    if ($request->has('coursier_id') && $request->input('coursier_id') != '') {
        $plisQuery->whereHas('attributions', function ($query) use ($request) {
            $query->where('coursier_depot_id', $request->input('coursier_id'));
        });
    }

    // Récupérer les plis filtrés
    $plis = $plisQuery->get();

    // Passer les plis et les coursiers à la vue
    return view('admin.attributions.depot', compact('coursiers', 'plis'));
}

// public function pliDejaAttribue($pli)
// {
//     return $pli->attribution()->exists();
// }



        public function pliDejaAttribue($pliId)
        {
            $pli = Pli::find($pliId); //  Charge l'objet via son ID

            if (!$pli) {
                return false; //  Empêche une erreur si `$pli` n'existe pas
            }

            return $pli->attributions()->exists(); //  Vérifie l’existence d’une attribution
        }




}
