<?php

namespace App\Http\Controllers;

use App\Models\rc;
use App\Models\Pli;
use App\Models\Coursier;
use App\Models\Destinataire;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;

class PliController extends Controller
{
    /**
     * Display a listing of the resource.
     */


    public function index()
    {
        $plis = Pli::paginate(10); // Affichage paginé
        $coursiers = Coursier::all();
        $destinataires = Destinataire::all();

        return view('admin.plis.index', compact('plies', 'coursiers', 'destinataires'));
    }


    // public function index(Request $request)
    // {
    //     $query = Pli::query();

    //     // Vérifie si l'utilisateur est un administrateur ou un utilisateur basique
    //     if (Auth::user()->role_as == '1') {
    //         // Administrateur : récupération de tous les plis
    //         $query->orderBy('created_at', 'desc');
    //     } else {
    //         // Utilisateur basique : récupérer uniquement ses propres plis
    //         $query->where('user_id', Auth::id())->orderBy('created_at', 'desc');
    //     }

    //     // Filtrer par nom de destinataire
    //     if ($request->filled('destinataire_name')) {
    //         $query->where('destinataire_name', 'like', '%' . $request->destinataire_name . '%');
    //     }

    //     // Filtrer par statut
    //     if ($request->filled('status')) {
    //         $query->whereHas('currentStatus', function ($query) use ($request) {
    //             $query->where('name', 'like', '%' . $request->status . '%');
    //         });
    //     }

    //     // Filtrer par intervalle de dates
    //     if ($request->filled('start_date') && $request->filled('end_date')) {
    //         $startDate = Carbon::parse($request->input('start_date'))->startOfDay();
    //         $endDate = Carbon::parse($request->input('end_date'))->endOfDay();
    //         $query->whereBetween('created_at', [$startDate, $endDate]);
    //     }

    //     // Filtrer par coursier ramassage
    //     if ($request->filled('coursier_ramassage')) {
    //         $query->whereHas('attributions', function ($q) use ($request) {
    //             $q->where('coursier_ramassage_id', $request->coursier_ramassage);
    //         });
    //     }

    //     // Filtrer par coursier dépôt
    //     if ($request->filled('coursier_depot')) {
    //         $query->whereHas('attributions', function ($q) use ($request) {
    //             $q->where('coursier_depot_id', $request->coursier_depot);
    //         });


    //     //     $plis = Pli::paginate(10); // Affichage paginé
    //     //    $coursiers = Coursier::all();
    //     //     $destinataires = Destinataire::all();

    //         //  return view('admin.plis.index', compact('plies', 'coursiers', 'destinataires'));

    //     }


    //       // Récupérer les 5 derniers plis créés
    //       $derniersPlis = Pli::orderBy('created_at', 'desc')->limit(5)->get();

    //       // Nombre de plis créés par période
    //       $aujourdhui = Pli::whereDate('created_at', Carbon::today())->count();
    //       $hier = Pli::whereDate('created_at', Carbon::yesterday())->count();
    //       $semaineDerniere = Pli::whereBetween('created_at', [Carbon::now()->startOfWeek()->subWeek(), Carbon::now()->startOfWeek()])->count();
    //       $moisDernier = Pli::whereBetween('created_at', [Carbon::now()->startOfMonth()->subMonth(), Carbon::now()->startOfMonth()])->count();


    //     // **Nombre total de plis après filtrage**
    //     $totalPlis = $query->count();

    //     // Récupérer les plis filtrés avec pagination
    //     $plis = $query->paginate(1500);

    //     // Récupérer les destinataires de l'utilisateur connecté
    //     $destinataires = Pli::where('user_id', Auth::id())
    //         ->select('destinataire_name')
    //         ->distinct()
    //         ->get();



    //     // Récupérer les coursiers
    //     $coursiers = Coursier::select('id', 'prenoms', 'nom')
    //         ->orderBy('nom', 'asc')
    //         ->orderBy('prenoms', 'asc')
    //         ->get();

    //     // Retourner la vue avec les données supplémentaires

    //     // if (Auth::user()->role_as == '1') {
    //     //      return view('admin.plis.index', compact('plis', 'destinataires', 'coursiers', 'totalPlis'));
    //     //     }

    //     // else {
    //     //     return view('client.plis.index', compact('plis', 'destinataires', 'totalPlis','derniersPlis', 'aujourdhui', 'hier', 'semaineDerniere', 'moisDernier'));
    //     //     }

    //     return view('admin.plis.index', compact('plis', 'destinataires', 'coursiers', 'totalPlis'));


    // }

//     public function index(Request $request)
// {
//     $query = Pli::query();

//     // 🔹 Vérification du rôle de l'utilisateur
//     if (Auth::user()->role_as == '1') {
//         // 🔥 Administrateur : récupérer tous les plis
//         $query->orderBy('created_at', 'desc');
//     } else {
//         // 🔥 Utilisateur basique : récupérer uniquement ses propres plis
//         $query->where('user_id', Auth::id())->orderBy('created_at', 'desc');
//     }

//     // 🔹 Filtrer par nom de destinataire (évite l'erreur NULL)
//     if ($request->filled('destinataire_name')) {
//         $query->whereHas('destinataire', function ($q) use ($request) {
//             $q->where('name', 'like', '%' . $request->destinataire_name . '%');
//         });
//     }

//     // 🔹 Filtrer par statut
//     if ($request->filled('status')) {
//         $query->whereHas('currentStatus', function ($q) use ($request) {
//             $q->where('name', 'like', '%' . $request->status . '%');
//         });
//     }

//     // 🔹 Filtrer par intervalle de dates
//     if ($request->filled('start_date') && $request->filled('end_date')) {
//         $startDate = Carbon::parse($request->input('start_date'))->startOfDay();
//         $endDate = Carbon::parse($request->input('end_date'))->endOfDay();
//         $query->whereBetween('created_at', [$startDate, $endDate]);
//     }

//     // 🔹 Filtrer par coursier ramassage
//     if ($request->filled('coursier_ramassage')) {
//         $query->whereHas('attributions', function ($q) use ($request) {
//             $q->where('coursier_ramassage_id', $request->coursier_ramassage);
//         });
//     }

//     // 🔹 Filtrer par coursier dépôt
//     if ($request->filled('coursier_depot')) {
//         $query->whereHas('attributions', function ($q) use ($request) {
//             $q->where('coursier_depot_id', $request->coursier_depot);
//         });
//     }

//     // 🔹 Récupérer les plis filtrés avec pagination
//     $plis = $query->paginate(1500);

//     // 🔹 Récupérer les destinataires **sans erreur NULL**
//     $destinataires = Destinataire::whereHas('plis', function ($q) {
//         $q->where('user_id', Auth::id());
//     })->select('name')->distinct()->get();

//     // 🔹 Récupérer les coursiers
//     $coursiers = Coursier::select('id', 'prenoms', 'nom')
//         ->orderBy('nom', 'asc')
//         ->orderBy('prenoms', 'asc')
//         ->get();

//     // 🔹 Nombre total de plis après filtrage
//     $totalPlis = $query->count();

//     // 🔥 Redirection vers la vue correcte
//     return view('admin.plis.index', compact('plis', 'destinataires', 'coursiers', 'totalPlis'));
// }



    // public function cancel_pli() //Retourne  que les plis qui ont été annulés
    //     {
    //         if($plis->id == $pli_statuer_history->pli_id) // Vérifie le pli existe dans historic_stat
    //             {
    //                 if($pli_statuer_history == 4) //Verifie l'etat du statut, annulé
    //                     {

    //                             //Action

    //                     }
    //             }
    //     }



    /**
     * Show the form for creating a new resource.
     */
    // public function create()
    // {
    //     //
    // }

    // /**
    //  * Store a newly created resource in storage.
    //  */
    // public function store(Request $request)
    // {
    //     //
    // }

    // /**
    //  * Display the specified resource.
    //  */
    // public function show(rc $rc)
    // {
    //     //
    // }

    // /**
    //  * Show the form for editing the specified resource.
    //  */
    // public function edit(rc $rc)
    // {
    //     //
    // }

    // /**
    //  * Update the specified resource in storage.
    //  */
    // public function update(Request $request, rc $rc)
    // {
    //     //
    // }

    // /**
    //  * Remove the specified resource from storage.
    //  */
    // public function destroy(rc $rc)
    // {
    //     //
    // }
}
