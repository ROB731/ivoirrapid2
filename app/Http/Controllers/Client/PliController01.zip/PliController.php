<?php


namespace App\Http\Controllers\Client;
use Carbon\Carbon;
use App\Models\Pli;
use App\Models\User;
use App\Models\Statuer;
use App\Models\Coursier;
use App\Models\Destinataire;
use Illuminate\Http\Request;
use App\Models\HistoriquePli;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Models\PliStatuerHistory;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Client\PliFormRequest;


class PliController extends Controller
{



// -----------------------Pour l'historique des plis finalisé

public function historiquePlis(Request $request) {

    // Pour le formulaire de filtre
            //  Ajout du filtre par date à la requête-------------------------------------------------

            $query = Pli::query();

            //  Filtrer par statut si sélectionné
            if ($request->filled('statut')) {
                $query->whereHas('statuerHistories', function ($q) use ($request) {
                    $q->where('statuer_id', $request->input('statut'));
                });
            }
            //  Filtrer par plage de dates si sélectionnée
            if ($request->filled('date_debut') && $request->filled('date_fin')) {
                $query->whereBetween('date_attribution_depot', [
                    $request->input('date_debut'),
                    $request->input('date_fin')
                ]);
            }
            //  Exécuter la requête avec pagination
            $listePlisFinalisesr1 = $query->orderBy('date_attribution_depot', 'desc')->paginate(10);

    // Fin formulaire de filtre--------------------------------

    // Définition des statuts finalisés
    $statutsFinalises = ['déposé', 'annulé', 'refusé'];

    // Récupération des IDs des statuts finalisés
    $statuerIdsFinalises = Statuer::whereIn('name', $statutsFinalises)->pluck('id')->toArray();


    $listePlisFinalises = Pli::whereHas('statuerHistories', function ($query) use ($statuerIdsFinalises) {
        $query->whereIn('statuer_id', $statuerIdsFinalises);
    })
    ->with([
        'statuerHistories.statuer',
        'destinataire',
        'user',
        'attributions.coursierRamassage',
        'attributions.coursierDepot',
    ])
    ->orderBy('date_attribution_depot', 'desc') // 🔥 Trie du plus récent au moins récent
    ->paginate(200); // 🔥 Ajoute la pagination avec 10 plis par page


    foreach ($listePlisFinalises as $pli) {
        $dateRamassage = $pli->date_attribution_ramassage ? Carbon::parse($pli->date_attribution_ramassage) : null;
        $dateDepot = $pli->date_attribution_depot ? Carbon::parse($pli->date_attribution_depot) : null;

        if ($dateRamassage && $dateDepot) {
            $pli->dureeLivraison = $dateDepot->diffInDays($dateRamassage) . ' jours';
        } else {
            $pli->dureeLivraison = 'Non défini';
        }
    }


    foreach ($listePlisFinalises as $pli) { // pour la date du statut
        $dernierStatut = $pli->statuerHistories->last();
        $pli->dateDecision = $dernierStatut ? Carbon::parse($dernierStatut->created_at)->format('d/m/Y') : 'Non défini';
    }

    return view('admin.plis.historique_plis', compact('listePlisFinalises', 'statuerIdsFinalises'));
}




// public function rechercherPlisHistorique(Request $request) {
//     $query = Pli::query();

//     // 🔥 Appliquer les filtres
//     if ($request->filled('statut')) {
//         $query->whereHas('statuerHistories', function ($q) use ($request) {
//             $q->where('statuer_id', $request->input('statut'));
//         });
//     }

//     if ($request->filled('date_debut') && $request->filled('date_fin')) {
//         $query->whereBetween('date_attribution_depot', [
//             $request->input('date_debut'),
//             $request->input('date_fin')
//         ]);
//     }

//     // 🔥 Vérifier si l'appel vient de "historiquePlis" pour définir le format du retour
//     if ($request->header('X-Page') === 'historiquePlis') {
//         $listePlisFinalises = $query->orderBy('date_attribution_depot', 'desc')->paginate(10);
//         return view('admin.plis.historique_plis', compact('listePlisFinalises'));
//     }

//     return response()->json($query->orderBy('date_attribution_depot', 'desc')->get());
// }



// public function rechercherPlisHistoriqueCompact(Request $request) {
//     $query = Pli::query();

//     if ($request->filled('date_debut') && $request->filled('date_fin')) {
//         $query->whereBetween('date_attribution_depot', [
//             $request->input('date_debut'),
//             $request->input('date_fin')
//         ]);
//     }

//     // 🔥 Retourne seulement les ID et le statut en JSON pour un affichage compact
//     return response()->json($query->orderBy('date_attribution_depot', 'desc')
//         ->select('id', 'statuerHistories')
//         ->get());
// }
    // --------------------------------------

public function index(Request $request) //La fonction index d'affichage
{

    $codeRecherche = $request->input('code');//  Récupère le code depuis la requête utilisateur

    // Optimiser pour les admoinistrateur

    // Pour l'affichage des statistique des suivi de pli
    $statutsFinaux = ['déposé', 'annulé', 'refusé'];

    // Récupération des IDs des statuts finaux
    $statuerIds = Statuer::whereIn('name', $statutsFinaux)->pluck('id')->toArray();

    $detailsPlis = Pli::join('pli_statuer_history', 'plies.id', '=', 'pli_statuer_history.pli_id')
        ->whereIn('pli_statuer_history.statuer_id', $statuerIds)
        ->groupBy('pli_statuer_history.statuer_id')
        ->selectRaw('pli_statuer_history.statuer_id, COUNT(*) as total')
        ->pluck('total', 'pli_statuer_history.statuer_id')
        ->toArray();

    // Charger les noms des statuts pour éviter l'erreur dans Blade
    $statuerNames = Statuer::whereIn('id', array_keys($detailsPlis))->pluck('name', 'id')->toArray();
    $totalPlisFinalises = array_sum($detailsPlis);

     //  Plis attribués au dépôt
     $plisDeposes = Pli::leftJoin('attributions', 'plies.id', '=', 'attributions.pli_id')
     ->whereNotNull('attributions.coursier_depot_id')
     ->select('plies.*', 'attributions.coursier_depot_id')
     ->paginate(10);

     //  Récupérer tous les plis qui ont été ramassés

     $plisRamasses = Pli::whereHas('attributions', function ($query) {
        $query->whereNotNull('coursier_ramassage_id'); // Sélectionne les attributions où le pli a été ramassé
    })->with('attributions')->get(); // Charge aussi les infos des attributions liées

    // $plisASuivre = Pli::whereDoesntHave('statuerHistories', function ($query) {
    //     $query->whereIn('statuer_id', [3, 4, 5]); // Exclure les statuts finaux (Déposé, Annulé, Refusé)
    // })->whereHas('attributions', function ($query) {
    //     $query->whereNotNull('coursier_ramassage_id'); // Vérifier qu’un coursier a bien été assigné pour le ramassage
    // })->get();

    $plisASuivre = Pli::whereDoesntHave('statuerHistories', function ($query) {
        $query->whereIn('statuer_id', [3, 4, 5]); // Exclure les statuts finaux (Déposé, Annulé, Refusé)
    })->whereHas('attributions', function ($query) {
        $query->whereNotNull('coursier_ramassage_id'); // Vérifier qu’un coursier a été assigné pour le ramassage
    })->orderByRaw("
        CASE
            WHEN EXISTS (SELECT 1 FROM attributions WHERE attributions.pli_id = plies.id
                AND attributions.coursier_ramassage_id IS NOT NULL
                AND attributions.coursier_depot_id IS NOT NULL) THEN 1
            ELSE 2
        END, created_at DESC
    ")->get();

    // Fin optimoiser pour les admin
    // ---------------------------Dedebut pour l'affichage -------------------------------------------------------

    $query = Pli::query();

    // Vérifie si l'utilisateur est un administrateur ou un utilisateur basique
    if (Auth::user()->role_as == '1') {
        // Administrateur : récupération de tous les plis
        $query->orderBy('created_at', 'desc');
    } else {
        // Utilisateur basique : récupérer uniquement ses propres plis
        $query->where('user_id', Auth::id())->orderBy('created_at', 'desc');
    }

    // Pour le formulaire de filtre debut ------------------------------------------------------------------------------------------------
    // Filtrer par nom de destinataire
    if ($request->filled('destinataire_name')) {
        $query->where('destinataire_name', 'like', '%' . $request->destinataire_name . '%');
    }

    // Filtrer par statut
            if ($request->filled('status')) {
                $query->whereHas('currentStatus', function ($query) use ($request) {
                    $query->where('name', 'like', '%' . $request->status . '%');
                });
    //Par numero de suivi filtre
                 }

                 //Rcherche avec le code ----------------------

    // $codeRecherche = $request->input('code');//  Récupère le code depuis la requête utilisateur
                // if (!empty($codeRecherche)) {

                //     $plis = Pli::query()
                //     ->where('code', $codeRecherche) // 🔍 Recherche par code
                //     ->whereDoesntHave('statuerHistories', function ($query) {
                //         $query->whereIn('statuer_id', [3, 4, 5]); // 🚀 Exclut les statuts finaux (Déposé, Annulé, Refusé)
                //     })
                //     ->whereHas('attributions', function ($query) {
                //         $query->whereNotNull('coursier_ramassage_id'); // 🎯 Assure qu’un coursier a été assigné pour le ramassage
                //     })
                //     ->orderByRaw("
                //         CASE
                //             WHEN EXISTS (
                //                 SELECT 1 FROM attributions
                //                 WHERE attributions.pli_id = plies.id
                //                 AND attributions.coursier_ramassage_id IS NOT NULL
                //                 AND attributions.coursier_depot_id IS NOT NULL
                //             ) THEN 1
                //             ELSE 2
                //         END, created_at DESC
                //     ")
                //     ->get();

                //         }

                // else {
                //     $plis = $plisASuivre;
                // }

    // Filtrer par intervalle de dates
    if ($request->filled('start_date') && $request->filled('end_date')) {
        $startDate = Carbon::parse($request->input('start_date'))->startOfDay();
        $endDate = Carbon::parse($request->input('end_date'))->endOfDay();
        $query->whereBetween('created_at', [$startDate, $endDate]);
    }

    // Filtrer par coursier ramassage
    if ($request->filled('coursier_ramassage')) {
        $query->whereHas('attributions', function ($q) use ($request) {
            $q->where('coursier_ramassage_id', $request->coursier_ramassage);
        });
    }

    // Filtrer par coursier dépôt
    if ($request->filled('coursier_depot')) {
        $query->whereHas('attributions', function ($q) use ($request) {
            $q->where('coursier_depot_id', $request->coursier_depot);
        });
    }
    // **Nombre total de plis après filtrage**
    $totalPlis = $query->count();

    // Récupérer les plis filtrés avec pagination



    // if ($request->has('code') || ($request->filled('start_date') && $request->filled('end_date'))) {
    //     if ($request->filled('start_date') && $request->filled('end_date')) { // 🔥 Vérifie que les deux dates sont bien renseignées
    //         $query->whereBetween('created_at', [$request->input('start_date'), $request->input('end_date')]);
    //     }

    //     $plis = $query->paginate(1500);
    // } else {
    //     $plis = Pli::whereDoesntHave('statuerHistories', function ($query) {
    //         $query->whereIn('statuer_id', [3, 4, 5]); // Exclure les statuts finaux (Déposé, Annulé, Refusé)
    //     })->whereHas('attributions', function ($query) {
    //         $query->whereNotNull('coursier_ramassage_id'); // Vérifier qu’un coursier a été assigné pour le ramassage
    //     })->orderByRaw("
    //         CASE
    //             WHEN EXISTS (
    //                 SELECT 1 FROM attributions
    //                 WHERE attributions.pli_id = plies.id
    //                 AND attributions.coursier_ramassage_id IS NOT NULL
    //                 AND attributions.coursier_depot_id IS NOT NULL
    //             ) THEN 1
    //             ELSE 2
    //         END, created_at DESC
    //        ")->paginate(500); //  Ajoute la pagination ici aussi

    // }



    $plis = $query->paginate(1500);


    // - formulaire  fin --------------------------------------------------------------------------------------------------------------------


    // Récupérer les destinataires de l'utilisateur connecté
    $destinataires = Pli::where('user_id', Auth::id())
        ->select('destinataire_name')
        ->distinct()
        ->get();

    // Récupérer les coursiers
    $coursiers = Coursier::select('id', 'prenoms', 'nom')
        ->orderBy('nom', 'asc')
        ->orderBy('prenoms', 'asc')
        ->get();

    //Bottom to add new functions :)
    $plisNonAttrib = Pli::whereDoesntHave('attributions')->get();

        $derniersPlis = Pli::orderBy('created_at', 'desc')->limit(5)->get();

        // Nombre de plis créés par période
        $aujourdhui = Pli::whereDate('created_at', Carbon::today())->count();
        $hier = Pli::whereDate('created_at', Carbon::yesterday())->count();
        $semaineDerniere = Pli::whereBetween('created_at', [Carbon::now()->startOfWeek()->subWeek(), Carbon::now()->startOfWeek()])->count();
        $moisDernier = Pli::whereBetween('created_at', [Carbon::now()->startOfMonth()->subMonth(), Carbon::now()->startOfMonth()])->count();

        // Pli pres 72h
        // $plisAttribuesSansStatutFinal = Pli::whereHas('attributions', function ($query) {
        //         $query->whereNotNull('coursier_ramassage_id')
        //               ->whereNotNull('coursier_depot_id'); // 🔥 Plis attribués au ramassage et dépôt
        //     })
        //     ->whereDoesntHave('statuerHistories', function ($query) {
        //         $query->whereIn('statuer_id', [3, 5]); // ❌ Exclut ces statuts finaux
        //     })
        //     ->where('created_at', '<=', Carbon::now()->subHours(72)) // ⏳ Plus de 72h depuis la création
        //     ->get();

        $plisAttribuesSansStatutFinal = 0;


    // Retourner la vue avec les données supplémentaires
    if (Auth::user()->role_as == '1') {
        return view('admin.plis.index', compact('plis', 'destinataires', 'coursiers', 'totalPlis','plisRamasses','plisASuivre','detailsPlis','totalPlisFinalises','statuerNames','plisNonAttrib','plisAttribuesSansStatutFinal')); // Pour l'administrateur
    } else {
        // return view('client.plis.index', compact('plis', 'destinataires', 'totalPlis')); // Pour l'utilisateur
        return view('client.plis.index', compact('plis', 'destinataires', 'totalPlis','derniersPlis', 'aujourdhui', 'hier', 'semaineDerniere', 'moisDernier',)); // Pour l'utilisateur plus les statistiques

    }
}




// Pour gerer les actions des utilisateurs :


// -------------------------------------------------------------01-05-2025----------------------------------------------------------------------------------------------------------------------------
public function pliesSupprimesParClient(Request $request)
{
    //  Sélectionner uniquement les plis supprimés
    $query = HistoriquePli::where('action', 'supprimé');

    // 📌 Vérifier si une recherche est faite
    if ($request->has('search') && !empty($request->search)) {
        $search = $request->search;

        $query->where(function ($q) use ($search) {
            $q->where('ancienne_valeur', 'LIKE', "%$search%")
              ->orWhere('nouvelle_valeur', 'LIKE', "%$search%");
        });
    }

    //  Comptage du total de plis supprimés
    $totalPliesSupprimes = $query->count();

    //  Paginé à 10 résultats par page
    $pliesSupprimes = $query->paginate(40);

    return view('admin.plis.plis_trashed', compact('pliesSupprimes', 'totalPliesSupprimes'));
}

// Restauration des plis supprimer-------------------------------------01-05-2025
public function restaurerPli($historique_id)
{
    //  Trouver l'historique du pli supprimé
    $historique = HistoriquePli::findOrFail($historique_id);

    // 🛠 Convertir les anciennes valeurs JSON en tableau
    $ancienneValeur = json_decode($historique->ancienne_valeur, true);

    // 🔄 Réinsérer le pli supprimé dans la table `plies`
    $pliRestauré = Pli::create($ancienneValeur);

    //  Ajouter un enregistrement dans l'historique pour signaler la restauration
    HistoriquePli::create([
        'pli_id' => $pliRestauré->id,
        'client_id' => auth()->id(),
        'action' => 'restauré',
        'ancienne_valeur' => json_encode($ancienneValeur),
        'nouvelle_valeur' => json_encode($pliRestauré->getAttributes()),
        'date_action' => now(),
    ]);

    return redirect()->route('admin.plis.plis_trashed')->with('success', 'Pli restauré avec succès.');

}


public function supprimerPli(Pli $pli)
{
    HistoriquePli::create([
        'pli_id' => $pli->id,
        'client_id' => auth()->id(),
        'action' => 'supprimé',
        'ancienne_valeur' => json_encode($pli->getOriginal()),
        'date_action' => now(),
    ]);

    $pli->forceDelete();

    return redirect()->route('client.plis.index')->with('success', 'Pli N°:'.$pli->code .' a été Supprimé définitivement Aujourd\'hui.');
}


// Fin de d'ajout fonction pour les action    01-05-2025 ---------------------------------------------------------------------------------------------------------------------------------------------------











        public function create() // pROBLEME D'icrementation lorsque on clique deux fois, on doit pas cliqué deux fois
    {
            // Récupérer les destinataires pour l'utilisateur connecté
            // $destinataires = Destinataire::where('user_id', Auth::id())->get();

            $destinataires = Destinataire::orderBy('name', 'asc')->get(); // Ici pour créer les plis, les utilisateur on accès à touts les utilisateur

            // Format 'yy-mm' de l'année et du mois en cours
            $yearMonth = Carbon::now()->format('y-m');

            // Trouver le dernier pli créé pour cet utilisateur avec un code commençant par 'yy-mm'

            $lastPli = Pli::where('user_id', Auth::id())
                ->where('code', 'like', "$yearMonth%")
                ->orderBy('created_at', 'desc')
                ->first();

            // Si un pli existe, incrémenter le numéro de suivi, sinon commencer à 1
            $nextNumber = $lastPli ? intval(substr($lastPli->code, -6)) + 1 : 1;

            // Compléter le numéro pour qu'il ait 6 chiffres
            $nextNumberPadded = str_pad($nextNumber, 6, '0', STR_PAD_LEFT);
            // Générer le code unique avec le format 'yy-mm-XXXXXX'
            $code = "$yearMonth-$nextNumberPadded";
            // Vérifier si le code existe déjà
            $existingPli = Pli::where('code', $code)->first();

        if ($existingPli) {
            // Le code existe encore, incrémenter à nouveau
                $nextNumber++;
                $nextNumberPadded = str_pad($nextNumber, 6, '0', STR_PAD_LEFT);
                $code = "$yearMonth-$nextNumberPadded";
            }
        else // Nouvelle ajout
            {
                $nextNumber;
                $nextNumberPadded = str_pad($nextNumber, 6, '0', STR_PAD_LEFT);
                $code = "$yearMonth-$nextNumberPadded";
            }


            // La référence est vide pour l'instant, tu peux ajouter une logique pour la générer si nécessaire
            $reference = '';

    // Passer les destinataires, le code et la référence à la vue
    return view('client.plis.create', compact('destinataires', 'code', 'reference'));
}

    // Fonction show pour afficher un pli spécifique
    public function show($id)
    {
        $pli = Pli::findOrFail($id);

        // Vérifier si l'utilisateur est admin ou client
        if (auth()->user()->role_as == 1) {  // Admin
            return view('admin.plis.show', compact('pli'));
        } else {  // Client
            return view('client.plis.show', compact('pli'));
        }
    }

    // Stocker un nouveau pli

    public function store(PliFormRequest $request)
    {
        $data = $request->validated();
        $pli = new Pli();
        $pli->destinataire_id = $data['destinataire_id'];
        $pli->user_id = Auth::id();

        // Récupérer les informations du destinataire
        $destinataire = Destinataire::findOrFail($data['destinataire_id']);
        $pli->destinataire_name = $destinataire->name;
        $pli->destinataire_adresse = $destinataire->adresse;
        $pli->destinataire_telephone = $destinataire->telephone;
        $pli->destinataire_email = $destinataire->email;
        $pli->destinataire_zone = $destinataire->zone;
        $pli->destinataire_contact = $destinataire->contact;
        $pli->destinataire_autre = $destinataire->autre;

        // Récupérer les informations de l'expéditeur
        $user = Auth::user();
        $pli->user_name = $user->name;
        $pli->user_adresse = $user->Adresse;
        $pli->user_telephone = $user->Telephone;
        $pli->user_email = $user->email;
        $pli->user_zone = $user->Zone;
        $pli->user_cellulaire = $user->Cellulaire;
        $pli->user_autre = $user->Autre;
        // $pli->statut='1';

        $pli->type = $data['type'];
        $pli->nombre_de_pieces = $data['nombre_de_pieces'];
        $pli->reference = implode(' | ', $data['reference']);

        $year = Carbon::now()->format('y');
        $month = Carbon::now()->format('m');
        $userAbreviation = strtolower(str_replace(' ', '_', $user->abreviation));

        $lastPli = Pli::where('user_id', Auth::id())
            ->where('code', 'like', "$userAbreviation-$year-$month%")
            ->orderBy('created_at', 'desc')
            ->first();

        $nextNumber = $lastPli ? intval(substr($lastPli->code, -6)) + 1 : 1;
        $nextNumberPadded = str_pad($nextNumber, 6, '0', STR_PAD_LEFT);
        $pli->code = "$userAbreviation-$year-$month-$nextNumberPadded";

        // Ajout des dates d'attribution dynamiques pour ramassage et dépôt
        $pli->date_attribution_ramassage = Carbon::now();
        $pli->date_attribution_depot = Carbon::now(); // exemple d'ajout de 3 jours pour dépôt

        $pli->save();

        return redirect()->route('client.plis.index')->with('success', 'Pli créé avec succès.');
    }

// ---------------------------------------------------------------------------------------------------------------------------------

    // public function changeStatuer($pliId, Request $request)
    // {
    //     $pli = Pli::findOrFail($pliId);
    //     $statuer = Statuer::where('name', $request->statuer)->first();

    //     if (!$statuer) {
    //         return redirect()->route('admin.plis.index')->with('error', 'Le statut spécifié est invalide.');
    //     }

    //     // Vérifier si le statut est "annulé"
    //     $raisonAnnulation = $request->statuer === 'annulé' ? $request->raison : null;

    //     // Créer un nouvel enregistrement dans pli_statuer_history
    //     $pliStatuerHistory = new PliStatuerHistory([
    //         'pli_id' => $pli->id,
    //         'statuer_id' => $statuer->id,
    //         'date_changement' => now(),
    //         'raison_annulation' => $raisonAnnulation,
    //     ]);
    //     $pliStatuerHistory->save();

    //     return redirect()->route('admin.plis.index')->with('success', 'Statut mis à jour avec succès.');
    // }

    public function changeStatuer(Request $request, Pli $pli)
{
    $nouveauStatut = $request->input('statuer');
    $raison = $request->input('raison');

    // Vérification des prérequis avant changement de statut
    if (in_array($nouveauStatut, ['déposé', 'refusé'])) {
        if (!$pli->attributions()->whereNotNull('coursier_ramassage_id')->whereNotNull('coursier_depot_id')->exists()) {
            // dd($nouveauStatut);
            return redirect()->back()->with('error', 'Le pli doit être attribué à un coursier pour le ramassage et le dépôt avant de pouvoir être déposé ou refusé.');

        }
    } elseif ($nouveauStatut == 'annulé') {
        if ($pli->attributions()->whereNotNull('coursier_depot_id')->exists()) {
            // dd($nouveauStatut);
            return redirect()->back()->with('error', 'Le pli ne peut plus être annulé après avoir reçu un coursier pour le dépôt.');

        }
    }

    // Vérification de la présence d'une raison pour "Annulé" et "Refusé"
    // if (in_array($nouveauStatut, ['annulé', 'refusé']) && empty($raison)) {
    //     return redirect()->back()->with('error', 'Une raison doit être fournie pour ce statut.');
    // }

    // Mise à jour du statut avec enregistrement de la raison
    PliStatuerHistory::create([
        'pli_id' => $pli->id,
        'statuer_id' => Statuer::where('name', $nouveauStatut)->first()->id,
        'date_changement' => now(),
        'raison_annulation' => in_array($nouveauStatut, ['annulé', 'refusé']) ? $raison : null
    ]);

    return redirect()->back()->with('success', 'Le statut du pli a été mis à jour avec succès.');
}


    // ------------------------------------------------------------------------------------------------------------------------------------


    public function edit($id)
{
    $pli = Pli::findOrFail($id); // Récupérer le pli à éditer
    $destinataires = Destinataire::where('user_id', Auth::id())->get(); // Récupérer les destinataires de l'utilisateur authentifié

    return view('client.plis.edit', compact('pli', 'destinataires'));
}

public function update(PliFormRequest $request, $pli_id)
{
    $data = $request->validated();
    $pli = Pli::find($pli_id);
    $pli->destinataire_id = $data['destinataire_id'];
    $pli->user_id = Auth::id();

    // Récupérer les informations du destinataire
    $destinataire = Destinataire::findOrFail($data['destinataire_id']);
    $pli->destinataire_name = $destinataire->name;
    $pli->destinataire_adresse = $destinataire->adresse;
    $pli->destinataire_telephone = $destinataire->telephone;
    $pli->destinataire_email = $destinataire->email;
    $pli->destinataire_zone = $destinataire->zone;
    $pli->destinataire_contact = $destinataire->contact;
    $pli->destinataire_autre = $destinataire->autre;

    // Récupérer les informations de l'expéditeur
    $user = Auth::user();
    $pli->user_name = $user->name;
    $pli->user_adresse = $user->Adresse;
    $pli->user_telephone = $user->Telephone;
    $pli->user_email = $user->email;
    $pli->user_zone = $user->Zone;
    $pli->user_cellulaire = $user->Cellulaire;
    $pli->user_autre = $user->Autre;

    $pli->type = $data['type'];
    $pli->nombre_de_pieces = $data['nombre_de_pieces'];
    $pli->reference = implode(' | ', $data['reference']);

    $year = Carbon::now()->format('y');
    $month = Carbon::now()->format('m');
    $userName = strtolower(str_replace(' ', '_', $user->name));

    $lastPli = Pli::where('user_id', Auth::id())
        ->where('code', 'like', "$userName-$year-$month%")
        ->orderBy('created_at', 'desc')
        ->first();

    $nextNumber = $lastPli ? intval(substr($lastPli->code, -6)) + 1 : 1;
    $nextNumberPadded = str_pad($nextNumber, 6, '0', STR_PAD_LEFT);
    // $pli->code = "$userName-$year-$month-$nextNumberPadded";

    // Ajout des dates d'attribution dynamiques pour ramassage et dépôt
    $pli->date_attribution_ramassage = Carbon::now();
    $pli->date_attribution_depot = Carbon::now(); // exemple d'ajout de 3 jours pour dépôt

    $pli->update();

    // Rediriger avec un message de succès
    return redirect()->route('client.plis.index')->with('success', 'Pli mis à jour avec succès!');
}

/*public function destroy($pli_id){
    $pli = Pli::find($pli_id);
    if ($pli)
    {
        $pli->delete();
        return redirect()->route('client.plis.index')->with('success', 'Pli supprimé avec succès.');
    }
    else{
        return redirect()->route('client.plis.index')->with('error', 'Pli non trouvé');
    }
}*/

public function destroy($pli_id){
    $pli = Pli::find($pli_id);
    if ($pli)
    {
        // Utilise forceDelete pour supprimer définitivement le pli
        $pli->forceDelete();
        return redirect()->route('client.plis.index')->with('success', 'Pli supprimé définitivement avec succès.');
    }
    else{
        return redirect()->route('client.plis.index')->with('error', 'Pli non trouvé');
    }

}


public function showAccuseDeRetour($pliId)
{
    $pli = Pli::with('statuerHistories.statuer')->findOrFail($pliId); // Charge l'historique avec le statut
    return view('admin.plis.accuse_retour', compact('pli'));
}

}
