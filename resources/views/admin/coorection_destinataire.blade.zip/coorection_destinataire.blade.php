
            @php
                use Carbon\Carbon;
                    if(isset($_GET['searchZone'])) {
                                $searchZone = $_GET['searchZone'];
                                $destinataires = \App\Models\Destinataire::where('zone', $searchZone)
                                                ->select('id', 'name', 'adresse', 'contact', 'zone')
                                                ->get(); //  Ajout de paginate(50)
                            $msgZone = 'Recherche effectuer pour la zone : '. $searchZone . '/ Nombre de destonataires '.$n=\App\Models\Destinataire::where('zone', $searchZone)->count();
                            $AutremsgZone = " Désolé impossible de changer la zone ou l'adresse dire clique sur Aller à pour modifier";

                            } else {

                                $destinataires = \App\Models\Destinataire::where('zone', '000')
                                                ->select('id', 'name', 'adresse', 'contact', 'zone')
                                                ->get(); //  Ajout de paginate(50)
                                        // $msgZone = 'Recherche effectuer pour la zone : '. $searchZone;

                                    // $msgZone = 'Affichage des destinataires récemment créés dans ce mois de  ' . Carbon::now()->translatedFormat('F');
                                     $destCount =  \App\Models\Destinataire::where('zone', '000')->count();
                                    $msgZone = 'Affichage des destinataires récemment ou présent dans la zone "000"  '. $destCount .' destinataire(s)' ;
                                     $AutremsgZone="";
                            }

                            // -------------------------
                        @endphp

            <div class="modal fade " id="destinataires" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> <span style="color:red"> {{  $msgZone }} .</span> <br>  <br> <i>  {{  $AutremsgZone }} </i>  </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
            {{-- --------------------------------------------------------------------- --}}

            <div class="modal-body">
                <div>
                    <!-- Formulaire de recherche amélioré -->
                            <form method="get" class="form-control">
                                @csrf
                                <input type="text" name="searchZone" id="searchZone" class="form-control" placeholder="Recherchez une zone..." required>
                                <button type="submit" class="btn btn-primary mt-2">🔍 Rechercher</button>
                                <a href="{{ url()->current() }}" class="btn btn-text">
                                    🔄 Rafraichir
                                </a>
                            </form>
                        <hr>
                        <!--  Liste des destinataires avec format amélioré -->
                    <table class="table table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Nom</th>
                            <th>Adresse</th>
                            <th>Zone</th>

                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($destinataires as $index => $dest)
                            <tr>
                                <td>{{ $index + 1 }}</td> <!--  Numéro automatique -->
                                <td>{{ $dest->name }}</td>
                                <td>{{ $dest->adresse }}</td>

                                <td><span class="badge bg-info">{{ $dest->zone }}</span></td>
                                <td>
                                 <a href="{{ url('client/edit-destinataire/'.$dest->id) }}" class="btn btn-sm btn-primary">
                                        ✏️ Modifier
                                    </a>
                                </td>
                            </tr>

            <!--  Ligne de modification avec meilleure structure -->


            @if (empty($_GET['searchZone']))


                    <form  method="get" style="display:inline">
                        <tr style="background:#f8f9fa !important" id="ligne{{ $index + 1 }}">
                            <td colspan="2">
                                <input type="text" class="form-control" placeholder="Modifier la zone de {{ $dest->name }}" name="zoneD[{{ $dest->id }}]" list="plageZonesList">

                            </td>
                            <td colspan="2">
                                <input type="text" class="form-control" placeholder="Modifier l'adresse de {{ $dest->name }}" name="adresseD[{{ $dest->id }}]">

                            </td>
                            <td>
                                @php
                                        if (isset($_GET['zoneD'][$dest->id]) || isset($_GET['adresseD'][$dest->id])) {
                                            $zoneD = !empty($_GET['zoneD'][$dest->id]) ? $_GET['zoneD'][$dest->id] : $dest->zone;
                                            $adresseD = !empty($_GET['adresseD'][$dest->id]) ? $_GET['adresseD'][$dest->id] : $dest->adresse;

                                            $recupDest = \App\Models\Destinataire::find($dest->id);

                                            if ($recupDest) {
                                                $recupDest->update([
                                                    'zone' => $zoneD,
                                                    'adresse' => $adresseD,
                                                ]);

                                                echo('

                                                <script>
                                                    alert("Modifier avec succes ✅")
                                                </script>

                                                ');

                                            }
                                            else {
                                                 echo('

                                                <script>
                                                    alert("Ooops une erreur est survenue X")
                                                </script>

                                                ');
                                            }

                                        }
                                    @endphp
                                 <button type="submit" class="btn btn-sm btn-success">
                                    ✅Valider
                                </button>

                               </td>



                            </tr>
                        </form>
                @else

                              {{-- <tr>
                                <td>  <a href="{{ url('client/edit-destinataire/'.$dest->id) }}" class="btn btn-sm btn-primary">
                                    ✏️ Modifier
                                </a></td>
                              </tr> --}}


                 @endif





        @endforeach
    </tbody>
</table>
    </div>
</div>

    <style>
        svg{
            display:none;
        }
    </style>

{{-- --- Paginations-------------- --}}

{{-- <div class="mt-3" style="text-align: center">
    {{ $destinataires->links() }} <!-- Affiche les boutons de navigation -->
</div> --}}
{{-- Pagination ---------------------------------- --}}

     {{-- ------------------------------------- --}}
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>


        <form method="get">
                 <button type="submit" class="btn btn-primary" name="massModify">Modifier</button>
        </form>
      </div>


    </div>
  </div>
</div>




