@extends('layouts.master')

@section('title', 'IvoirRp - Admin')

@include('admin.dashbord_stat')

@section('content')

    <div class="container-fluid px-4">
        <h1 class="mt-4">Tableau de bord</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active"></li>
        </ol>

        <h3 class="mt-4">Récapitulatif général </h3>
        <hr>

        <div class="row">
            {{-- Statistiques générales --}}
            <div class="col-xl-3 col-md-6">
                <div class="card bg-info text-white mb-4">
                    <div class="card-body">Total Clients</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white stretched-link" href="#">{{ $totalUsers }}</a>
                        <div class="medium text-white"><i class="fas fa-address-book"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card bg-success text-white mb-4">
                    <div class="card-body">Total Destinataires</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white stretched-link" href="#">{{ $totalDestinataires }}</a>
                        <div class="medium text-white"><i class="fas fa-user-check"></i></div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="card bg-success text-white mb-4">
                    <div class="card-body">Total Coursiers</div>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white stretched-link" href="#">  {{ $totalCoursiers }} </a>
                        <div class="medium text-white"><i class="fas fa-user-check"></i></div>
                    </div>
                </div>
            </div>
        </div>

         <h3 class="mt-4">Statistique de Traitement des plis et Moyenne Par Jour </h3>
                @yield('stat-moy-day')

{{-- ------------------------------------------------------------------------------------- --}}

{{-- ---------------------------------------------------------------------- --}}

            <hr>
           {{-- États des plis --}}
            @foreach([
                ['title' => 'En attente', 'count' => $plisEnAttenteSemaine ?? 0, 'color' => 'secondary', 'icon' => 'hourglass-start'],
                ['title' => 'Ramasses', 'count' => $plisRamassesSemaine ?? 0, 'color' => 'primary', 'icon' => 'hand-holding'],
                ['title' => 'Deposes', 'count' => $plisDeposésSemaine ?? 0, 'color' => 'success', 'icon' => 'box'],
                ['title' => 'Annules', 'count' => $plisAnnulesSemaine ?? 0, 'color' => 'danger', 'icon' => 'times-circle'],
                ['title' => 'Retournes', 'count' => $plisRetournesSemaine ?? 0, 'color' => 'warning', 'icon' => 'undo-alt'],
                ['title' => 'Non Traites', 'count' => $plisNonTraites ?? 0, 'color' => 'dark', 'icon' => 'exclamation-circle'],
                ['title' => 'Total Cette semaine', 'count' => $plisSemaine ?? 0, 'color' => 'primary', 'icon' => ''],


            ] as $statut)
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-{{ $statut['color'] }} text-white mb-4">
                        <div class="card-body">{{ $statut['title'] }}</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="#">{{ $statut['count'] }}</a>
                            <div class="medium text-white"><i class="fas fa-{{ $statut['icon'] }}"></i></div>
                        </div>
                    </div>
                </div>
            @endforeach

            {{-- Statistique des plies créé --}}

            <h3 class="mt-4">Statistiques des plis crees</h3>

                <div class="col-xl-4 col-md-6">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-body">Plis aujourd hui</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="#">{{ $plisJour ?? 0 }}</a>
                            <div class="medium text-white"><i class="fas fa-calendar-day"></i></div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-body">Plis de la semaine</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="#">{{ $plisSemaine ?? 0 }}</a>
                            <div class="medium text-white"><i class="fas fa-calendar-week"></i></div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-body">Plis du weekend</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="#">{{ $plisWeekend ?? 0 }}</a>
                            <div class="medium text-white"><i class="fas fa-calendar-alt"></i></div>
                        </div>
                    </div>
                </div>

                <h3 class="mt-4">Jours et semaines de fort trafic</h3>

                <div class="row">
                    <div class="col-md-6">
                        <div class="card bg-danger text-white mb-4">
                            <div class="card-body">Jours les plus charges</div>
                            <ul class="list-group list-group-flush">
                                @foreach($joursFortTrafic as $jour)
                                    <li class="list-group-item">{{ $jour->jour }} : {{ $jour->total }} plis</li>
                                @endforeach
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card bg-warning text-dark mb-4">
                            <div class="card-body">Semaines les plus charges</div>
                            <ul class="list-group list-group-flush">
                                @foreach($semainesFortTrafic as $semaine)
                                    <li class="list-group-item">Semaine {{ $semaine->semaine }} : {{ $semaine->total }} plis</li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </div>

                <h3 class="mt-4">Mois de fort trafic et comparaison</h3>

        <div class="row">
            <div class="col-md-6">
                <div class="card bg-danger text-white mb-4">
                    <div class="card-body">Mois les plus charges</div>
                    <ul class="list-group list-group-flush">
                        @foreach($moisFortTrafic as $mois)
                            <li class="list-group-item">Mois {{ $mois->mois }} / {{ $mois->annee }} : {{ $mois->total }} plis</li>
                        @endforeach
                    </ul>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card bg-warning text-dark mb-4">
                    <div class="card-body">Comparaison entre les mois</div>
                    <p>Mois actuel : {{ $comparaisonActivite['mois_actuel'] }} plis</p>
                    <p>Mois precedent : {{ $comparaisonActivite['mois_precedent'] }} plis</p>
                    <p>Evolution : <strong>{{ $comparaisonActivite['variation'] > 0 ? '+'.$comparaisonActivite['variation'] : $comparaisonActivite['variation'] }}</strong> plis</p>
                </div>
            </div>
        </div>
        {{-- --------------------------------------- --}}

                    <h3 class="mt-4">Activite sur 12 mois et comparaison</h3>

            <div class="row">
                <div class="col-md-12">
                    <div class="card bg-info text-white mb-4">
                        <div class="card-body">Evolution de l activite sur 12 mois</div>
                        <table class="table table-bordered text-white">
                            <thead>
                                <tr>
                                    <th>Mois</th>
                                    <th>Annee</th>
                                    <th>Total Plis</th>
                                    <th>Variation</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($comparaisonActivite12Mois as $mois)
                                    <tr>
                                        <td>{{ $mois['mois'] }}</td>
                                        <td>{{ $mois['annee'] }}</td>
                                        <td>{{ $mois['total'] }}</td>
                                        <td class="{{ $mois['variation'] > 0 ? 'text-success' : 'text-danger' }}">
                                            {{ $mois['variation'] > 0 ? '+' . $mois['variation'] : $mois['variation'] }}
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {{-- Pour les graphiques  --}}
            <div class="alert alert-info text-center">
                🚀 **À bientôt pour la visualisation graphique !**
                Les données statistiques sont en cours de traitement. Revenez bientôt pour voir les graphiques dynamiques ! 📊✨
            </div>

            </div>

        {{-- / fin facture --}}

        </div>
    </div>
@endsection

{{-- Pour le graphique --}}
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

