@section('stat-moy-day')
    {{-- Statistique des plis et Moyenne par jour ------------------------------------------------------- --}}
    <div class="container" style="display:flex;gap:10%; margin-bottom:10px">
        <div class="rows">
            <small>
                Les étapes de traitement d'un pli sont les suivantes :
                <i>
                    <ol>
                        <li>Création de plis par le client</li>
                        <li>Ramassage par un coursier d'IVOIRRAPID</li>
                        <li>Attribution à un coursier pour le dépôt ou livraison du pli</li>
                        <li>Changement de statut ou état du pli (Annulé, Déposé, Refusé)</li>
                    </ol>
                </i>
            </small>
        </div> <!--  Ajout de la fermeture correcte -->

        @php
            $debutAnnee = now()->startOfYear();
            $totalPlis = \App\Models\Pli::where('created_at', '>=', $debutAnnee)->count();
            $nbJours = now()->diffInDays($debutAnnee) + 1;
            $moyenneQuotidienne = $nbJours > 0 ? $totalPlis / $nbJours : 0;

            //  Génération des dates depuis le 1er janvier
            $dates = [];
            $plisParJour = [];

            for ($i = 0; $i < $nbJours; $i++) {
                $date = $debutAnnee->copy()->addDays($i)->format('Y-m-d');
                $dates[] = $date;
                $plisParJour[] = \App\Models\Pli::whereDate('created_at', $date)->count();
            }
        @endphp

        <div class="row">
            <!--  Card pour afficher les statistiques -->
            <div class="col-md" style="width:70%">
                <div class="card text-center shadow-lg">
                    <div class="card-body">
                        <h5 class="card-title">📊 Statistiques des Plis</h5>
                        <p class="card-text">Depuis le <strong>1er janvier</strong> :</p>
                        <h3 class="text-primary">{{ number_format($totalPlis) }}</h3> <!--  Total des plis -->
                        <p class="text-muted">Plis créés aujourd'hui : <strong>{{ number_format($plisParJour[count($plisParJour) - 1]) }}</strong></p>
                    </div>
                </div>
            </div>


        </div>
    </div> <!--  Fermeture complète de `container` -->




      <!--  Graphique des plis -->

          <div class="text-center">
            <button id="btnJour" class="btn btn-primary">📅 Afficher par Jour</button>
            <button id="btnSemaine" class="btn btn-success">🗓️ Afficher par Semaine</button>
            <button id="btnMois" class="btn btn-warning">📆 Afficher par Mois</button> <!-- ✅ Nouveau bouton -->
        </div>

    <div id="recapGraphique" class="alert alert-info text-center mt-3">
        <h5>📊 Récapitulatif</h5>
        <p id="modeAffichage">Mode : <strong>Jour</strong></p>
        <p id="nombrePlis">Total de plis : <strong>0</strong></p>
        <p id="moyennePlis">Moyenne par période : <strong>0</strong></p>
        <p id="nombrePlusBas">Plus faible création : <strong>0</strong></p>
        <p id="conclusion">Conclusion : <strong>État inconnu</strong></p>
    </div>



<canvas id="pliChart"></canvas>



             <div class="col-md" style="height:; width:90%; margin:auto;padding-right:10px">
                <canvas id="pliChart"></canvas>
            </div>

        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
       <script>
    const ctx = document.getElementById('pliChart').getContext('2d');

    let labels = {!! json_encode($dates) !!}; // 📅 Dates journalières
    let dataPlis = {!! json_encode($plisParJour) !!}; // 📊 Plis créés par jour

    let pliChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Plis créés',
                data: dataPlis,
                borderColor: '#007bff',
                backgroundColor: 'rgba(0, 123, 255, 0.2)',
                fill: true
            }]
        }
    });

    // ✅ Fonction pour regrouper par semaine
    function regrouperParSemaine() {
        let semaines = {};
        labels.forEach((date, index) => {
            let semaine = new Date(date).getWeek();
            semaines[semaine] = (semaines[semaine] || 0) + dataPlis[index];
        });

        return {
            labels: Object.keys(semaines),
            data: Object.values(semaines)
        };
    }

    // ✅ Fonction pour regrouper par mois
    function regrouperParMois() {
        let mois = {};
        labels.forEach((date, index) => {
            let moisKey = date.substring(0, 7); // Format YYYY-MM (ex: "2025-05")
            mois[moisKey] = (mois[moisKey] || 0) + dataPlis[index];
        });

        return {
            labels: Object.keys(mois),
            data: Object.values(mois)
        };
    }

    // ✅ Bouton "Afficher par Semaine"
    document.getElementById('btnSemaine').addEventListener('click', () => {
        let semaineData = regrouperParSemaine();
        pliChart.data.labels = semaineData.labels;
        pliChart.data.datasets[0].data = semaineData.data;
        pliChart.update();
    });

    // ✅ Bouton "Afficher par Jour"
    document.getElementById('btnJour').addEventListener('click', () => {
        pliChart.data.labels = labels;
        pliChart.data.datasets[0].data = dataPlis;
        pliChart.update();
    });

    // ✅ Bouton "Afficher par Mois"
    document.getElementById('btnMois').addEventListener('click', () => {
        let moisData = regrouperParMois();
        pliChart.data.labels = moisData.labels;
        pliChart.data.datasets[0].data = moisData.data;
        pliChart.update();
    });

    // ✅ Fonction pour calculer la semaine d'une date
    Date.prototype.getWeek = function() {
        let date = new Date(this);
        date.setHours(0, 0, 0, 0);
        date.setDate(date.getDate() + 4 - (date.getDay() || 7));
        let yearStart = new Date(date.getFullYear(), 0, 1);
        return Math.ceil((((date - yearStart) / 86400000) + 1) / 7);
    };
</script>

    <script>
    function afficherRecap(mode, data, total) {
        let totalPlis = total;
        let moyennePlis = data.length > 0 ? (totalPlis / data.length).toFixed(2) : 0;
        let minPlis = Math.min(...data);
        let maxPlis = Math.max(...data);
        let tendance = maxPlis > minPlis ? "📈 HUP (Hausse)" : "📉 DOWN (Baisse)";

        document.getElementById("modeAffichage").innerHTML = `Mode : <strong>${mode}</strong>`;
        document.getElementById("nombrePlis").innerHTML = `Total de plis : <strong>${totalPlis}</strong>`;
        document.getElementById("moyennePlis").innerHTML = `Moyenne par ${mode.toLowerCase()} : <strong>${moyennePlis}</strong>`;
        document.getElementById("nombrePlusBas").innerHTML = `Plus faible création : <strong>${minPlis}</strong>`;
        document.getElementById("conclusion").innerHTML = `Conclusion : <strong>${tendance}</strong>`;
    }

    document.getElementById('btnSemaine').addEventListener('click', () => {
        let semaineData = regrouperParSemaine();
        let totalPlis = semaineData.data.reduce((a, b) => a + b, 0);
        pliChart.data.labels = semaineData.labels;
        pliChart.data.datasets[0].data = semaineData.data;
        pliChart.update();

        afficherRecap("Semaine", semaineData.data, totalPlis);
    });

    document.getElementById('btnJour').addEventListener('click', () => {
        let totalPlis = dataPlis.reduce((a, b) => a + b, 0);
        pliChart.data.labels = labels;
        pliChart.data.datasets[0].data = dataPlis;
        pliChart.update();

        afficherRecap("Jour", dataPlis, totalPlis);
    });

    document.getElementById('btnMois').addEventListener('click', () => {
        let moisData = regrouperParMois();
        let totalPlis = moisData.data.reduce((a, b) => a + b, 0);
        pliChart.data.labels = moisData.labels;
        pliChart.data.datasets[0].data = moisData.data;
        pliChart.update();

        afficherRecap("Mois", moisData.data, totalPlis);
    });
</script>





@endsection
