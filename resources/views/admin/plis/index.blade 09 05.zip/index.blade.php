@extends('layouts.master')

@section('title', 'IvoirRp - Plis')

@section('content')

<div class="container-fluid px-4">
            <h2 class="mt-4">Gestion des Plis (Suivi de statuts)</h2>
            <hr>

{{-- Ajout le 02-05-2025---------------------------------------------pour le signalement en cas de facture sans état final ------------------------}}
            <div>
                @if(($plisAttribuesSansStatutFinal)> 0)
                <div class="clignotant">
                    {{-- ⚠️ Plis Non livrés après 72H : {{ count($plisAttribuesSansStatutFinal) }} ⚠️ --}}
                    ⚠️ Plis Non livrés après 72H : ⚠️
                </div>
                @else
                {{-- <p>Aucun pli en retard</p> --}}
                @endif
            </div>


        <style>
        @keyframes clignoter {
            0% { color: red; }
            50% { color: white; }
            100% { color: red; }
        }

        .clignotant {
            font-weight: bold;
            font-size: 40px;
            animation: clignoter 1s infinite;
            text-align: center;
        }
        </style>
{{-- Fin ajout 02-05-2025--------------------------------------------------------------------------------------------------------------- --}}



{{-- Oiur le recap des plis bouton non cliquable ------------------------------------------------------------------------------------------------ --}}
<div class="card card-sm" style="gap:; display: flex; text-align:">
    <div class="card-body">
        <h6 class="card-title">📌 Plis Finalisés (Total : <strong>{{ $totalPlisFinalises }}</strong>)</h6>



        <div class="statuts-wrapper d-flex justify-content-start align-items-center flex-wrap">

            <div class="statut-item alert-warning">
                📦 Nombre de plis non attribués : <strong>{{ count($plisNonAttrib) ?? 'Aucun'}}</strong>
            </div>


            @foreach($detailsPlis as $statuerId => $total)
                <div class="statut-item">
                    <strong>{{ $statuerNames[$statuerId] ?? 'Inconnu' }}</strong> : {{ $total }}
                </div>

            @endforeach

            <div  class="statut-item">
                @if (count($plisASuivre)!==0)
                        <strong class="text btn-text" style="color:green;">Plis à suivre : {{ count($plisASuivre) }}</strong>
                        {{-- <button class="btn btn-text" style="color:green;">Nombre de plis à suivre  {{ count($plisASuivre) }}</button> --}}

                @else
                    <h6>Vous n'avez aucun plis à suivre</h6>
                @endif

                 {{-- Lien pour l'historique des plis --}}

        </div>

        <a href="{{ route('plis.historique') }}" class="text text-danger statut-item" >
            Voir l'historique des plis finalisés
        </a>

        <a href="{{ route('admin.attributions.index') }}" class="text text-sm text-outline-primary" title="Attribuer"  style="">
            <i class="fas fa-user-plus"></i> Attribution des plis
        </a>


        <button class="btn">
            <a href="{{ route('admin.plis.plis_trashed') }}" class="btn btn-warning btn-sm">
                <i class="fas fa-trash"></i> Voir les plis supprimés
            </a>
        </button>

    </div>



    {{-- -----------------------------09-05-2025------------------------------- --}}

    <div class="card card-sm" style="display: flex; text-align: center;">
        <div class="card-body">
            <h6 class="card-title">📌 Plis Finalisés (Total : <strong>{{ $totalPlisFinalises }}</strong>)</h6>

            <div class="statuts-wrapper d-flex justify-content-center align-items-center flex-wrap gap-3">

                <!-- Plis non attribués -->
                {{-- <div class="statut-item circle-item alert-warning">
                    <i class="fas fa-box"></i>
                    <span>📦 Non attribués : <strong>{{ count($plisNonAttrib) ?? 'Aucun'}}</strong></span>
                </div> --}}

                <!-- Statuts des plis -->
                {{-- @foreach($detailsPlis as $statuerId => $total)
                    <div class="statut-item circle-item">
                        <i class="fas fa-folder"></i>
                        <strong>{{ $statuerNames[$statuerId] ?? 'Inconnu' }}</strong> : {{ $total }}
                    </div>
                @endforeach --}}

                <!-- Plis à suivre -->
                <div class="statut-item circle-item">
                    @if (count($plisASuivre)!==0)
                        <i class="fas fa-eye text-success"></i>
                        <span><strong style="color:green;">Plis à suivre : {{ count($plisASuivre) }}</strong></span>
                    @else
                        <h6>Vous n'avez aucun plis à suivre</h6>
                    @endif
                </div>

                <!-- Liens et actions dans des cercles -->
                <div class="circle-link">
                    <a href="{{ route('plis.historique') }}" class="circle-item text-danger">
                        <i class="fas fa-history"></i> <span>Historique</span>
                    </a>
                </div>

                <div class="circle-link">
                    <a href="{{ route('admin.attributions.index') }}" class="circle-item text-outline-primary">
                        <i class="fas fa-user-plus"></i> <span>Attributions</span>
                    </a>
                </div>

                <div class="circle-link">
                    <a href="{{ route('admin.plis.plis_trashed') }}" class="circle-item btn-warning btn-sm">
                        <i class="fas fa-trash"></i> <span>Plis supprimés</span>
                    </a>
                </div>

            </div>
        </div>
    </div>


        <style>

.circle-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 90px;
    height: 90px;
    border-radius: 50%;
    text-align: center;
    background-color: #f2f2f2;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
    padding: 10px;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.3s ease-in-out;
}

.circle-item i {
    font-size: 22px;
    margin-bottom: 5px;
}

.circle-item:hover {
    background-color: #d9d9d9;
    transform: scale(1.1);
}

/* Style spécial pour les liens */
.circle-link a {
    text-decoration: none;
    color: black;
    font-weight: bold;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.circle-link a span {
    font-size: 12px;
    margin-top: 5px;
}


        </style>




    {{-- -------------------09+-05-2025 --}}
{{-- Fin de recap button non cliquable -------------------------------------------------------------------------------------------- --}}


    <div class="search-bar mb-4">

{{--
        <div class="input-group">
            <!-- Bouton pour "Ramassage" avec une moto -->
            <a href="{{ route('admin.attributions.impression') }}" class="btn btn-primary mx-2" title="Ramassage">
                <i class="fas fa-motorcycle"></i>
            </a>

            <!-- Bouton pour "Dépot" -->
            <a href="{{ route('admin.attributions.depot') }}" class="btn btn-secondary mx-2" title="Dépôt">
                <i class="fas fa-warehouse"></i>
            </a>

            <!-- Bouton pour Export PDF -->
            <button id="export-pdf" class="btn btn-primary mx-2" title="Exporter en PDF">
                <i class="fas fa-file-pdf"></i>
            </button>
        </div> --}}


    </div>

    <div class="search-bar mb-4">
        {{-- <div class="input-group">
            <input type="text" id="searchInput" class="form-control" placeholder="Rechercher un pli..." />
            <button class="btn btn-primary" id="btnSearch" type="button">
                <i class="fas fa-search"></i>
            </button>
        </div> --}}
    </div>

    <!-- Filtres -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.plis.index') }}">
                @csrf
                <div class="row g-3 align-items-center">

                    <!-- Filtre par destinataire -->
                    <div class="col-md-4">
                        <label for="destinataireFilter" class="form-label">Destinataire</label>
                        <input type="text " name="destinataire_name" id="destinataireFilter" class="form-select" >
                        {{-- <select name="destinataire_name" id="destinataireFilter" class="form-select">
                            <option value="">-- Tous les destinataires --</option>
                            @foreach($destinataires as $destinataire)
                                <option value="{{ $destinataire->destinataire_name }}"
                                    {{ request('destinataire_name') == $destinataire->destinataire_name ? 'selected' : '' }}>
                                    {{ $destinataire->destinataire_name }}
                                </option>
                            @endforeach
                        </select> --}}
                    </div>

                    <!-- Filtre par coursier ramassage -->
                    <div class="col-md-4">
                        <label for="coursierRamassageFilter" class="form-label">Coursier (Ramassage)</label>
                        <select name="coursier_ramassage" id="coursierRamassageFilter" class="form-select">
                            <option value="">Tous les coursiers</option>
                            @foreach($coursiers as $coursier)
                                <option value="{{ $coursier->id }}"
                                    {{ request('coursier_ramassage') == $coursier->id ? 'selected' : '' }}>
                                    {{ $coursier->prenoms }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Filtre par coursier dépôt -->
                    <div class="col-md-4">
                        <label for="coursierDepotFilter" class="form-label">Coursier (Dépôt)</label>
                        <select name="coursier_depot" id="coursierDepotFilter" class="form-select">
                            <option value="">Tous les coursiers</option>
                            @foreach($coursiers as $coursier)
                                <option value="{{ $coursier->id }}"
                                    {{ request('coursier_depot') == $coursier->id ? 'selected' : '' }}>
                                    {{ $coursier->prenoms }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Filtres par dates -->
                    <div class="col-md-6">
                        <label for="startDate" class="form-label">Date début</label>
                        <input type="date" name="start_date" id="startDate" class="form-control" value="{{ request('start_date') }}">
                    </div>
                    <div class="col-md-6">
                        <label for="endDate" class="form-label">Date fin</label>
                        <input type="date" name="end_date" id="endDate" class="form-control" value="{{ request('end_date') }}">
                    </div>
                </div>

                <!-- Boutons -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>
                        <button type="submit" class="btn btn-primary" title="Appliquer les filtres">
                            <i class="fas fa-filter"></i>
                        </button>
                        <a href="{{ route('admin.plis.index') }}" class="btn btn-secondary" title="Effacer les filtres">
                            <i class="fas fa-redo"></i>
                        </a>

                    </div>
                </div>
                {{-- Barre de recherche specifique ---------------------------------------------------------------- --}}
                {{-- <div class="search-container">
                    <input type="text" name="code1" class="search-input" placeholder="Entrez le code du pli...">
                    <button class="search-button">Rechercher</button>
                </div> --}}
                    <style>
                                            .search-container {
                        display: flex;
                        justify-content: center; /* 🔥 Centre horizontalement */
                        align-items: center;
                        gap: 10px; /* ✅ Espacement entre l'input et le bouton */
                        margin-top: 20px;
                    }

                    .search-input {
                        padding: 8px 12px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        font-size: 16px;
                        width: 250px; /* ✅ Ajuste la largeur */
                    }

                    .search-button {
                        padding: 8px 15px;
                        background-color: #007bff; /* 🔥 Couleur bleu vif */
                        color: white;
                        border: none;
                        border-radius: 5px;
                        font-size: 16px;
                        cursor: pointer;
                        transition: background 0.3s ease-in-out;
                    }

                    .search-button:hover {
                        background-color: #0056b3; /*  Effet au survol */
                    }

                    </style>

                {{-- / barre de recherche ------------------- --}}


            </form>

            <form method="GET" action="{{ route('admin.plis.index') }}">
                <div class="search-container">
                        <input type="text" name="code" class="search-input" placeholder="Entrez le code du pli...">
                        <button class="search-button">Rechercher</button>
                    </div>
                </form>

        </div>

    </div>




    </div> <br>

{{-- Debut du tableau ---------------------------------------------------------------------------------------------------------------- --}}

{{-- Nombre de plis à suivre --}}



            {{-- Danger --}}




            {{-- Danger --}}
                <style>
                .statuts-wrapper {
                    display: flex;
                    flex-wrap: nowrap; /* Empêche les éléments de passer à la ligne */
                    gap: 10px; /* Espacement entre les éléments */
                    overflow-x: auto; /* Ajoute un scroll horizontal si nécessaire */
                }

                .statut-item {
                    background-color: #f8f9fa;
                    padding: 6px 12px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    font-size: 13px;
                    white-space: nowrap; /* Évite le retour à la ligne */
                }

                </style>

        </div>


        <div class="search-result"> <!-- Résultat de recherche -->
            @if(!empty($_GET['start_date']) && !empty($_GET['end_date']))
                <h5 class="result-title">🔎{{ count($plis) }} Résultat pour la recherche du <strong>{{ $_GET['start_date'] }}</strong> au <strong>{{ $_GET['end_date'] }}</strong></h5>
            @endif

            @if(!empty($_GET['code']))
                <h5 class="result-title">🔎 {{ count($plis) }} Résultat pour le code du pli <strong>{{ $_GET['code'] }}</strong></h5>
            @endif


            <style>
                .search-result {
                    text-align: center;
                    margin: 20px 0;
                    padding: 10px;
                    background-color: #f8f9fa; /* Fond léger */
                    border: 1px solid #ccc;
                    border-radius: 5px;
                }

                .result-title {
                    font-size: 18px;
                    font-weight: bold;
                    color: #00aa60; /* Bleu vif */
                }

            </style>
        </div>

<br>
<h5>Recherche rapide</h5>
<div class="input-group">

    <input type="text" id="searchInput" class="form-control" placeholder="Rechercher un pli par code..." />
    <button class="btn btn-primary" id="btnSearch" type="button">
        <i class="fas fa-search"></i>
    </button>
</div>

<style>
    .checkbox-container {
        background-color: #f8f9fa; /* Fond légèrement gris */
        padding: 10px;
        border-radius: 8px;
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        align-items: center;
        justify-content: start;
    }

    .checkbox-container label {
        display: flex;
        align-items: center;
        cursor: pointer;
        font-weight: bold;
        gap: 8px;
        padding: 6px 10px;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .checkbox-container label:hover {
        background-color: #e2e6ea;
    }

    /* Personnalisation du checkbox */
    .checkbox-container input[type="checkbox"] {
        accent-color: #007bff; /* Couleur lorsqu'il est coché */
        transform: scale(1.2); /* Taille légèrement augmentée */
    }
</style>

<br>
<h6>Mode d'affichage du tableau</h6>
<div class="checkbox-container">

    <label>
        <input type="checkbox" class="toggle-column" data-column="2" >
        Type
    </label>
    <label>
        <input type="checkbox" class="toggle-column" data-column="3" >
        Date de création du pli
    </label>
    <label>
        <input type="checkbox" class="toggle-column" data-column="9" >
        Date de Attribution Dépot
    </label>
    <label>
        <input type="checkbox" class="toggle-column" data-column="8" >
        Date Attribution Ramassage
    </label>

    <label>
        <input type="checkbox" class="toggle-column" data-column="11" >
        Actions
    </label>
</div>

{{-- Message d'erreur pour le suivi des stauts --}}

@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

@if(session('error'))
    <div class="alert alert-danger">
        {{ session('error') }}
    </div>
@endif

{{-- / Message d'erreur pour le suivi des stauts --}}


    <div class="table-responsive scrollable-container">
        <table class="table table-bordered table-striped mt-3">
            <thead class="bg-light text-center">
                <tr>
                    <th class="text-nowrap">#</th>
                    <th class="text-nowrap">No de Suivie</th>
                    <th class="text-nowrap hidden-column">Type</th>
                    <th class="text-nowrap hidden-column">Date de création</th>
                    <th class="text-nowrap">Client</th>
                    <th class="text-nowrap">Destinataire</th>
                    <th class="text-nowrap">Coursier Ramassage</th>
                    <th class="text-nowrap">Coursier Dépôt</th>
                    <th class="text-nowrap hidden-column">Date Attribution Ramassage</th>
                    <th class="text-nowrap hidden-column">Date Attribution Dépôt</th>
                    <th class="text-nowrap">Statut</th>
                    <th class="text-nowrap hidden-column">Actions</th>
                </tr>
            </thead>
            <style>
                         .table-responsive {
                    max-height: 500px; /* Ajuste la hauteur max selon ton besoin */
                    overflow-y: auto; /* Permet le défilement uniquement en vertical */
                    position: relative;
                }

                table {
                    width: 100%;
                    border-collapse: collapse;
                }

                thead {
                    position: sticky;
                    top: 0;
                    background-color: #f8f9fa; /* Fond fixe pour l’en-tête */
                    z-index: 10; /* Assure qu’il reste au-dessus du reste du tableau */
                    box-shadow: 0px 2px 5px rgba(0,0,0,0.1); /* Effet léger pour démarquer l’en-tête */
                }

            </style>
            <tbody>
                {{-- @foreach ($plis as $pli) --}}
                @foreach ($plis as $pli)
                {{-- @if (!empty($pli1) && $pli1->id) --}}
                    <tr>
                        <!-- No de Suivie -->
                        <td class="text-center text-nowrap">{{ $loop->iteration }}
                                <span style="size:9px !important">
                                    {{-- <td class="text-nowrap position-sticky" style="background-color: white; z-index: 10; right: 0;"> --}}
                                        @if (isset($pli->destinataire->id))
                                            <a href="{{ url('client/edit-destinataire/'.$pli->destinataire->id) }}" class="btn btn-warning btn-sm me-1" title="Editer le destinataire">
                                                <i class="fas fa-edit" title="Editer le destinataire"></i>
                                                {{-- <span> {{ $pli->user_name }} </span> --}}
                                            </a>
                                        @else
                                            <strong><span>Destinataire Supprimé</span></strong>

                                        @endif

                                </span>
                        </td>


                        <td class="text-center text-nowrap">{{ $pli->code }}

                        </td> {{-- Code du pli --}}
                        <td class="text-center text-nowrap hidden-column">{{ $pli->type }}</td> {{-- Type de pli --}}

                             <td class="text-center text-nowrap hidden-column">

                                    {{ $pli->created_at }}

                            </td> {{-- Date de création du pli --}}

                        <!-- Client -->
                        <td class="text-nowrap">
                            <div><strong>{{ $pli->user->name }}</strong></div> {{--Information du client  --}}
                            <div class="text-muted small">Tél: {{ $pli->user->Telephone ?? 'N/A' }}</div>
                            <div class="text-muted small"> {{ $pli->user->Zone ?? 'N/A' }}</div>
                        </td>
                        <!-- Destinataire -->
                        <td class="text-nowrap">
                            <div><strong>{{ $pli->destinataire->name ?? 'N/A' }}</strong>

                            </div>

                            <div class="text-muted small">Tél: {{ $pli->destinataire->telephone ?? 'N/A' }}</div>
                            <div class="text-muted small">Zone: {{ $pli->destinataire->zone ?? 'N/A' }}</div>
                        </td>
                        <!-- Coursiers -->
                        <td class="text-center text-nowrap">
                            {{ isset($pli->attributions[0]->coursierRamassage) ? $pli->attributions[0]->coursierRamassage->prenoms   ?? 'Non défini' : 'Non défini' }}

                            <div class="text-muted small">
                              {{ isset($pli->attributions[0]->coursierRamassage) ? $pli->attributions[0]->coursierRamassage->nom   ?? 'Non défini' : 'Non défini' }}
                            </div>
                            {{-- <div class="text-muted small">
                                {{ isset($pli->attributions[0]->coursierRamassage) ? $pli->attributions[0]->coursierRamassage->zones  ?? 'Non défini' : 'Non défini' }}
                              </div> --}}

                              <div class="text-muted small">
                                {{ isset($pli->attributions[0]->coursierRamassage) ? implode(', ', $pli->attributions[0]->coursierRamassage->zones) ?? 'Non défini' : 'Non défini' }}
                            </div>
                        </td>
                        <!-- Coursier de dépôt -->
                        <td class="text-center text-nowrap">
                            {{ isset($pli->attributions[0]->coursierDepot) ? $pli->attributions[0]->coursierDepot->prenoms ?? 'Aucun coursier' : 'Aucun coursier' }}

                            <div class="text-muted small">
                                {{ isset($pli->attributions[0]->coursierDepot) ? $pli->attributions[0]->coursierDepot->nom   ?? 'Non défini' : 'Non défini' }}
                              </div>
                              {{-- <div class="text-muted small">
                                  {{ isset($pli->attributions[0]->coursierRamassage) ? $pli->attributions[0]->coursierRamassage->zones  ?? 'Non défini' : 'Non défini' }}
                                </div> --}}

                                <div class="text-muted small">
                                  {{ isset($pli->attributions[0]->coursierDepot) ? implode(', ', $pli->attributions[0]->coursierDepot->zones) ?? 'Non défini' : 'Non défini' }}
                              </div>

                        </td>

                        <!-- Dates -->

                        <td class="text-center text-nowrap hidden-column">
                            {{ isset($pli->attributions[0]) && $pli->attributions[0]['date_attribution_ramassage']
                                ? \Carbon\Carbon::parse($pli->attributions[0]['date_attribution_ramassage'])->format('d/m/Y')
                                : 'Non défini' }}
                        </td>
                        <td class="text-center text-nowrap hidden-column">
                            {{ isset($pli->attributions[0]) && $pli->attributions[0]['date_attribution_depot']
                                ? \Carbon\Carbon::parse($pli->attributions[0]['date_attribution_depot'])->format('d/m/Y')
                                : 'Non défini' }}
                        </td>
                    {{-- Premier formulaire dans le tableau --}}
                        <td class="text-nowrap">
                            {{-- ---------------------------------------------------------- --}}
                            <form action="{{ route('plis.changeStatuer', $pli->id) }}" method="POST">
                                @csrf
                                <div id="statut-wrapper" class="zone-selection">
                                    <select name="statuer" id="statut-choice" class="form-control form-control-sm select-statut" required>
                                        <option value="">Sélectionner un statut</option>
                                        @foreach(['déposé', 'annulé', 'refusé'] as $statut)
                                            <option value="{{ $statut }}"
                                                {{ $pli->currentStatuer()?->statuer->name == $statut ? 'selected' : '' }}>
                                                {{ ucfirst($statut) }}
                                            </option>
                                        @endforeach
                                    </select>

                                    <div id="raison-wrapper" style="display: none;">
                                        <input type="text" name="raison" id="raison-field"
                                            class="form-control form-control-sm input-raison mt-2"
                                            placeholder="Raison de refus ou annulation"
                                            value="{{ $pli->currentStatuer()?->raison_annulation ?? '' }}">
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary btn-sm mt-2">Mettre à jour</button>
                            </form>
                            {{-- ---------------------------------------------------- --}}
                            <style>
                                /* Couleurs des statuts */
                                .statut-en-attente { background-color: #f4de79; } /* Jaune */
                                .statut-ramasse { background-color: #79c4f4 !important; } /* Bleu */
                                .statut-depose { background-color: #79f48c !important; } /* Vert */
                                .statut-annule { background-color: #f47a79 !important   ; } /* Rouge */
                                .statut-refuse { background-color: #d679f4 !important; } /* Violet */

                                         #raison-container.statut-actif {
                                        display: block !important;
                                        visibility: visible !important;
                                        opacity: 1 !important;
                                    }

                            </style>
                        </td>

                    {{-- Fin formulaire dans le tableau --}}

                        <!-- Actions -->
                        {{-- <td class="text-center text-nowrap">
                        </td> --}}

                        <td class="text-center text-nowrap hidden-column">
                            {{-- Pour les actions  ------------------------------------------------}}


                            <a href="{{ route('admin.plis.show', $pli->id) }}" class="btn btn-sm btn-outline-primary" title="Voir les détails">
                                <i class="fas fa-eye"></i>
                            </a>

                            <!-- Bouton pour afficher les détails des dates -->
                            <button class="btn btn-sm btn-outline-info mt-1 my-1" data-bs-toggle="modal" data-bs-target="#modalDates-{{ $pli->id }}" title="Voir les dates">
                                <i class="fas fa-calendar-alt"></i>
                            </button>
                            <a href="{{ route('plis.accuse_retour', $pli->id) }}" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-file-alt"></i> Accusé de Retour
                            </a>

                        </td>

                    </tr>

                    <!-- Modal pour les détails -->
                    <div class="modal fade" id="modalDates-{{ $pli->id }}" tabindex="-1" aria-labelledby="modalDatesLabel-{{ $pli->id }}" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalDatesLabel-{{ $pli->id }}">Détails des Dates</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                                </div>
                                <div class="modal-body">
                                    <ul class="list-group">
                                        <li class="list-group-item">
                                            <strong>Date En Attente :</strong>
                                            {{ $pli->statuerHistory->where('statuer_id', '1')->last()?->date_changement
                                                ? \Carbon\Carbon::parse($pli->statuerHistory->where('statuer_id', '1')->last()->date_changement)->format('d/m/Y H:i')
                                                : 'Non défini' }}
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Date Ramassé :</strong>
                                            {{ $pli->statuerHistory->where('statuer_id', '2')->last()?->date_changement
                                                ? \Carbon\Carbon::parse($pli->statuerHistory->where('statuer_id', '2')->last()->date_changement)->format('d/m/Y H:i')
                                                : 'Non défini' }}
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Date Déposé :</strong>
                                            {{ $pli->statuerHistory->where('statuer_id', '3')->last()?->date_changement
                                                ? \Carbon\Carbon::parse($pli->statuerHistory->where('statuer_id', '3')->last()->date_changement)->format('d/m/Y H:i')
                                                : 'Non défini' }}
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Date Annulé :</strong>
                                            {{ $pli->statuerHistory->where('statuer_id', '4')->last()?->date_changement
                                                ? \Carbon\Carbon::parse($pli->statuerHistory->where('statuer_id', '4')->last()->date_changement)->format('d/m/Y H:i')
                                                : 'Non défini' }}
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Date Retourné :</strong>
                                            {{ $pli->statuerHistory->where('statuer_id', '5')->last()?->date_changement
                                                ? \Carbon\Carbon::parse($pli->statuerHistory->where('statuer_id', '5')->last()->date_changement)->format('d/m/Y H:i')
                                                : 'Non défini' }}
                                        </li>
                                    </ul>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- @endif --}}

                @endforeach
            </tbody>
        </table>

    </div>



    {{-- fin du tableau --------------------------------------------------------------------------------------------------------------- --}}

    @if(session('message'))
        <div class="alert alert-success">{{ session('message') }}</div>
    @endif

</div>
<div class="d-flex justify-content-center">

    <ul class="pagination pagination-custom">
        {{-- Bouton Précédent --}}

         @if ($plis->onFirstPage())
            <li class="page-item disabled">
                <span class="page-link">Précédent</span>
            </li>
         @else
            <li class="page-item">
                <a class="page-link" href="{{ $plis->previousPageUrl() }}">Précédent</a>
            </li>
        @endif

        {{-- Pages --}}
        @foreach ($plis->getUrlRange(1, $plis->lastPage()) as $page => $url)
            <li class="page-item {{ $plis->currentPage() == $page ? 'active' : '' }}">
                <a class="page-link" href="{{ $url }}">{{ $page }}</a>
            </li>
        @endforeach

        {{-- Bouton Suivant --}}
        @if ($plis->hasMorePages())
            <li class="page-item">
                <a class="page-link" href="{{ $plis->nextPageUrl() }}">Suivant</a>
            </li>
        @else

            <li class="page-item disabled">
                <span class="page-link">Suivant</span>
            </li>
        @endif
    </ul>

</div>
<style>

    /* Pagination container */
.pagination-custom .page-link {
    border-radius: 25px; /* Boutons arrondis */
    margin: 0 5px;       /* Espacement entre les boutons */
    color: #007bff;      /* Couleur du texte */
    background-color: #f8f9fa; /* Couleur de fond */
    border: 1px solid #ddd;    /* Bordure légère */
    transition: all 0.3s ease; /* Animation lors du hover */
}
.d-flex {
    margin-top: 10px;
}



/* Effet hover */
.pagination-custom .page-link:hover {
    background-color: #007bff; /* Fond bleu au hover */
    color: #fff;               /* Texte blanc */
    border-color: #007bff;     /* Bordure bleue */
}.scrollable-container {
    max-height: 500px; /* Ajuste la hauteur max pour activer le scroll */
    overflow-x: auto; /* Permet le scroll horizontal */
    overflow-y: auto; /* Permet le scroll vertical */
    white-space: nowrap;
    position: relative;
}

.table {
    min-width: 100%; /* Empêche le tableau de rétrécir trop */
}

/* Fixe la colonne "Statut" */
th:nth-last-child(2), td:nth-last-child(2) {
    position: sticky;
    right: 100px; /* Ajuste selon la largeur de la colonne "Actions" */
    background: white;
    z-index: 2;
    box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
}

/* Fixe la colonne "Actions" */
th:last-child, td:last-child {
    position: sticky;
    right: 0;
    background: white;
    z-index: 3;
    box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
}

.hidden-column {
    display: none;
}



/* Bouton actif */
.pagination-custom .page-item.active .page-link {
    background-color: #007bff; /* Fond bleu pour l'actif */
    color: #fff;               /* Texte blanc */
    border-color: #007bff;     /* Bordure bleue */
}

/* Bouton désactivé */
.pagination-custom .page-item.disabled .page-link {
    background-color: #e9ecef; /* Fond gris clair */
    color: #6c757d;           /* Texte gris */
    border-color: #e9ecef;    /* Bordure gris clair */
    pointer-events: none;     /* Désactivation des clics */
}
.scrollable-container {
    max-height: 500px; /* Hauteur maximale pour le défilement vertical */
    overflow-x: auto; /* Défilement horizontal activé */
    overflow-y: auto; /* Défilement vertical activé */
    white-space: nowrap; /* Empêche les colonnes de se replier */
}

.table {
    min-width: 100%; /* Assure que le tableau occupe toujours la largeur nécessaire */
}
.scrollable-container::-webkit-scrollbar {
    width: 10px; /* Largeur de la barre horizontale */
    height: 10px; /* Hauteur de la barre verticale */
}

.scrollable-container::-webkit-scrollbar-thumb {
    background-color: #007bff; /* Couleur de la barre */
    border-radius: 5px;
}

.scrollable-container::-webkit-scrollbar-thumb:hover {
    background-color: #0056b3; /* Couleur survolée */
}

.scrollable-container::-webkit-scrollbar-track {
    background: #f1f1f1; /* Couleur du fond */
}
</style>
<script> // Pour la rechezrche dynamaique

    // document.addEventListener('DOMContentLoaded', function () {
    //     const searchInput = document.getElementById('searchInput');
    //     const tableRows = document.querySelectorAll('tbody tr');

    //     searchInput.addEventListener('keyup', function () {
    //         const searchTerm = this.value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

    //         tableRows.forEach(function (row) {
    //             const columns = row.querySelectorAll('td');
    //             let match = false;

    //             const searchColumns = [
    //                 0, // Code de suivi
    //             ];

    //             searchColumns.forEach(colIndex => {
    //                 const columnText = columns[colIndex].textContent.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    //                 if (columnText.includes(searchTerm)) {
    //                     match = true;
    //                 }
    //             });

    //             row.style.display = match ? '' : 'none';
    //         });
    //     });
    // });

            document.addEventListener('DOMContentLoaded', function () {
            const searchInput = document.getElementById('searchInput');
            const tableRows = document.querySelectorAll('tbody tr');

            searchInput.addEventListener('keyup', function () {
                const searchTerm = this.value.toLowerCase().trim();
                let hasMatch = false;

                tableRows.forEach(function (row) {
                    const columns = row.querySelectorAll('td');
                    let match = false;

                    if (columns.length > 1) {
                        const columnText = columns[1].textContent.toLowerCase().trim();

                        if (columnText.includes(searchTerm)) {
                            match = true;
                            hasMatch = true;
                        }
                    }

                    row.style.display = match ? '' : 'none';
                });

                // ✅ Si le champ de recherche est vide, réafficher toutes les lignes
                if (searchTerm === "") {
                    tableRows.forEach(row => row.style.display = '');
                }
            });
        });




</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.31/jspdf.plugin.autotable.min.js"></script>

<script>
    document.getElementById('export-pdf').addEventListener('click', function () {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Obtenir la valeur de la recherche
    const searchInput = document.getElementById('searchInput').value.toLowerCase();

    // Récupérer les données du tableau en filtrant selon la recherche
    const table = document.querySelector('.table');
    const rows = [...table.querySelectorAll('tbody tr')]
        .filter(row => {
            const clientCell = row.querySelector('td:nth-child(4)');
            const clientName = clientCell ? clientCell.querySelector('strong').innerText.toLowerCase() : '';
            // Vérifier si le nom du client correspond à la recherche
            return clientName.includes(searchInput);
        })
        .map(row => {
            const cells = row.querySelectorAll('td');
            return [
                cells[0]?.innerText || '',  // No de Suivie
                cells[1]?.innerText || '',  // Type
                cells[2]?.innerText || '',  // Date de création
                cells[9]?.querySelector('select')?.value || '',  // Statut actuel (récupère la valeur sélectionnée)
                cells[4]?.innerText.split('Tél: ')[1] || 'N/A',  // Téléphone D (récupère après "Tél: ")
                cells[4]?.querySelector('div strong')?.innerText || ''  // Destinataire (nom du destinataire)
            ];
        });

    // Si aucune correspondance, alerte l'utilisateur
    if (rows.length === 0) {
        alert('Aucun client trouvé pour cette recherche.');
        return;
    }

    // Ajouter le texte du titre et l'image (logo)
    doc.text('Liste des Plis', 14, 15);  // Titre du PDF
    doc.addImage("{{ asset('asset/Logo IRN.png') }}", 'PNG', 150, 5, 50, 20);  // Ajouter l'image à la droite du texte

    // Configurer le tableau dans le PDF
    doc.autoTable({
        head: [['No de Suivie', 'Type', 'Date de création', 'Statut', 'Téléphone D', 'Destinataire']],
        body: rows,
        startY: 30,  // Ajuster le début du tableau après le titre et le logo
        headStyles: { fillColor: [22, 160, 133] },
        styles: { fontSize: 10, cellPadding: 4 },
    });

    // Télécharger le fichier PDF avec le nom dynamique
    const clientName = rows[0] ? rows[0][5] : 'Client';  // Utiliser le nom du destinataire (ou 'Client' si vide)
    const date = new Date();
    const formattedDate = date.toISOString().split('T')[0];  // Format: YYYY-MM-DD
    const fileName = `${clientName}_${formattedDate}.pdf`;

    doc.save(fileName);  // Utiliser le nom dynamique du fichier
});

</script>


<script> // Pour les afficher et masquer les colonnes
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll(".toggle-column").forEach(function (checkbox) {
            checkbox.addEventListener("change", function () {
                let columnIndex = this.getAttribute("data-column");
                let isVisible = this.checked;
                document.querySelectorAll("table tr").forEach(function (row) {
                    row.children[columnIndex].classList.toggle("hidden-column", !isVisible);
                });
            });
        });
    });
</script>



<script> // Pour les zones du formulaire
        document.addEventListener("DOMContentLoaded", function() {
    // Sélectionner tous les formulaires de statut
    const selectStatuts = document.querySelectorAll(".select-statut");

    selectStatuts.forEach(selectElement => {
        // Détection de la zone de raison liée à ce select
        const raisonContainer = selectElement.closest('.zone-selection').querySelector("#raison-wrapper");

        function updateUI() {
            let statut = selectElement.value.trim().toLowerCase();

            if (statut === "annulé" || statut === "refusé") {
                raisonContainer.style.display = "block";
            } else {
                raisonContainer.style.display = "none";
            }
        }

        // Appliquer la logique lors du changement de statut
        selectElement.addEventListener("change", updateUI);

        // Vérification initiale lors du chargement de la page
        updateUI();
    });
});

</script>

        <audio id="alertSound">
            <source src="https://www.myinstants.com/media/sounds/alarm.mp3" type="audio/mpeg">
        </audio>

        <script> // Pour l'audio
                // window.onload = function() {
                //     document.getElementById("alertSound").play(); // 🔊 Joue le son à l’ouverture de la page
                // };
        </script>

        <script>
            window.onload = function() {
                let nombrePlisNonLivres = {{ $plisAttribuesSansStatutFinal }}; // 🔥 Récupère la valeur PHP


                if (nombrePlisNonLivres > 0) { // 🚨 Joue le son uniquement si danger
                    document.getElementById("alertSound").play();
                }
            };
        </script>

            {{-- <button onclick="playAlertSound()" class="btn btn-danger">🚨 Alerte Plis Non Livrés 🚨</button> --}}

                    <audio id="alertSound">
                        <source src="https://www.myinstants.com/media/sounds/alarm.mp3" type="audio/mpeg">
                    </audio>

                    <script>
                    function playAlertSound() {
                        let audio = document.getElementById("alertSound");
                        audio.play(); // 🔊 Joue le son lorsqu'on clique sur le bouton
                    }
                </script>

                <audio id="alertSound">
                    <source src="https://www.myinstants.com/media/sounds/alarm.mp3" type="audio/mpeg">
                </audio>

                <audio id="alertSound">
                    <source src="https://www.myinstants.com/media/sounds/alarm.mp3" type="audio/mpeg">
                </audio>

                <script>
                document.addEventListener("DOMContentLoaded", function() {
                    let nombrePlisNonLivres = {{ $plisAttribuesSansStatutFinal }}; // 🔥 Récupère la valeur Blade

                    function jouerAlerte() {
                        let count = 0;
                        if (nombrePlisNonLivres > 0) { // 🚨 Si nombre > 0, joue l'alerte 10 fois
                            let repeatSound = setInterval(() => {
                                if (count < 10) {
                                    document.getElementById("alertSound").play();
                                    count++;
                                } else {
                                    clearInterval(repeatSound);
                                }
                            }, 3000);
                        }
                    }

                    jouerAlerte(); // 🔥 Déclenche le son au chargement SI nombre > 0
                });
                </script>







@endsection
