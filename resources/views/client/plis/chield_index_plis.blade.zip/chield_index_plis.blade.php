
{{-- Pour les modals ---------------------------------------------------- --}}

{{-- Modal pour afficher les messages des plis qui on été ramassés ou attribué 06-05-2025 ------------------------------------------------------- --}}
{{-- Modal pour afficher les messages des plis qui on été ramassés ou attribué 06-05-2025 ------------------------------------------------------- --}}

<div>
    {{-- <h4> Plis  </h4> --}}
            <!-- Bouton pour ouvrir le modal -->

        {{-- <button type="button" class="btn btn-dark custom-btn" data-bs-toggle="modal" data-bs-target="#plisNonAttribuesModal" data-bs-toggle="tooltip" title="Voir les plis non attribués">
            🚨
        </button> --}}

            <!-- Modal Bootstrap  Pour afficher le modal des plis ramsaasé et qui doivent être deposé ------------------->
            <div class="modal fade" id="plisNonAttribuesModal" tabindex="-1" aria-labelledby="plisModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl" >
                    <div class="modal-content">
                        <div class="modal-header bg-success text-dark">
                            <h5 class="modal-title" id="plisModalLabel" style="color:white">📦 Plis  ramassés ou attribués</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">


                            <table class="table table-striped table-bordered table-hover mt-3" id="table-p">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col" class="text-nowrap-pr" style="white-space: nowrap;">#</th>
                                        <th scope="col" class="text-nowrap-pr" style="white-space: nowrap;">Messages</th> <!-- Show to print-->
                                        <th scope="col" class="text-nowrap-pr" style="white-space: nowrap;">Etat(Final)</th>  <!-- Show to print-->
                                        <th scope="col" class="text-nowrap hidden-column">Référence</th>
                                        <th scope="col" class="text-nowrap">Actions</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ( $plisRamassesOuAttribues as $pli)
                                    <tr>

                                        <td class="text-nowrap-pr hidden-column">{{ $loop->iteration }}</td>
                                        <td class="text-nowrap-pr hidden-column">

                                            <div class="alert alert">
                                            {{-- Message dans le cas il a été ramassé ------------------- --}}


                                            {{-- Pour afficher le message avec la date ----------------06-05-2025----------------------------- --}}

                                                    @if ($pli->attributions->last())
                                                    @if ($pli->attributions->last()->coursier_depot_id && $pli->attributions->last()->coursier_ramassage_id)
                                                        <div class="alert alert-primary">
                                                    🚀 Votre pli <strong>({{ $pli->type }})</strong> N° : <strong>{{ $pli->code }}</strong> a été attribué à un coursier pour le dépôt. Il est actuellement en transit vers son destinataire !
                                                </div>
                                                        @elseif ($pli->attributions->last()->coursier_ramassage_id)
                                                            <div class="alert alert-success">
                                                                ✅ Votre pli <strong>({{ $pli->type }})</strong> N° : <strong>{{ $pli->code }}</strong> a bien été ramassé le <strong>

                                                                        {{-- {{ $pli->attributions->last()->date_attribution_ramassage ? $pli->attributions->last()->date_attribution_ramassage : 'Date indisponible' }}</strong> --}}

                                                                        @if ($pli->attributions->last()->date_attribution_ramassage)
                                                                        <strong>
                                                                            {{ \Carbon\Carbon::parse($pli->attributions->last()->date_attribution_ramassage)->translatedFormat('l d F à H\hi s\s') }}
                                                                                </strong>
                                                                            @else
                                                                                <strong>Date indisponible</strong>
                                                                            @endif. Il est en cours de traitement pour livraison.
                                                            </div>
                                                        @endif
                                                        @else
                                                            <div class="alert alert-warning">
                                                                ⏳ Votre pli <strong>({{ $pli->type }})</strong> N° : <strong>{{ $pli->code }}</strong> est en attente de ramassage. Un coursier sera bientôt assigné.
                                                            </div>
                                                        @endif

                                                {{-- / fin pour afficher les statut avec le ramassage------------------------- --}}
                                            </div>

                                        </td>
                                        {{-- <td class="text-nowrap-pr" style="white-space: nowrap;">{{ $pli->code }}</td> <!-- Show to print--> --}}

                                        <td>
                                            {{-- Affiche les statuts --}}

                                                <span class="badge
                                                    @if ($pli->currentStatuer() && $pli->currentStatuer()->statuer->name == 'en attente')
                                                        bg-warning
                                                    @elseif ($pli->currentStatuer() && $pli->currentStatuer()->statuer->name == 'ramassé')
                                                        bg-info
                                                    @elseif ($pli->currentStatuer() && $pli->currentStatuer()->statuer->name == 'déposé')
                                                        bg-success
                                                    @elseif ($pli->currentStatuer() && $pli->currentStatuer()->statuer->name == 'annulé')
                                                        bg-danger
                                                    @elseif ($pli->currentStatuer() && $pli->currentStatuer()->statuer->name == 'retourné')
                                                        bg-success
                                                    @endif">
                                                    {{ $pli->currentStatuer() ? $pli->currentStatuer()->statuer->name : 'Non défini' }}
                                                </span>

                                        </td>

                                        {{-- <td class="text-nowrap-pr">{{ $pli->destinataire_name }}</td> --}}
                                        <td class="text-nowrap">
                                            <button class="btn btn-info btn-sm view-reference-btn" data-reference="{{ $pli->reference }}" data-bs-toggle="modal" data-bs-target="#referenceModal">Voir</button>
                                        </td>

                                   {{-- Debut action------------------------------------------- --}}
                                                    <td class="text-nowrap">
                                                        <a href="{{ route('client.plis.show', $pli->id) }}" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i></a>
                                                        <a href="{{ route('client.edit-pli', $pli->id) }}" class="btn
                                                            @if ($pli->currentStatuer() && in_array($pli->currentStatuer()->statuer->name, ['en attente', 'ramassé', 'déposé', 'annulé', 'retourné']))
                                                                btn-secondary disabled
                                                            @else
                                                                btn btn-warning btn-sm me-2
                                                            @endif
                                                            btn-sm">
                                                            <i class="fas fa-edit"></i>
                                                        </a>

                                                        <!--Bouton delete-->

                                                        {{-- <a href="{{ url('client/delete-pli/'.$pli->id) }}" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a> --}}
                                                        <a href="{{ route('plis.supprimer', $pli->id) }}" class="btn btn-danger btn-sm">
                                                            <i class="fas fa-trash"></i>
                                                        </a>

                                                        <a href="{{ route('plis.restaurer', $pli->id) }}" class="btn btn-success btn-sm">
                                                            <i class="fas fa-recycle"></i>
                                                        </a>
                                                 </td>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                        </div>
                    </div>
                </div>
            </div>

            <style>
                            .modal-header {
                                    position: sticky;
                                    top: 0;
                                    z-index: 1055;
                                    background-color: #198754; /* Couleur de fond verte (bg-success) */
                                }

            </style>
</div>

{{-- Fin du modal 06-05-2025----------------------------------------------------------------------------------- --}}
{{-- Fin du modal 06-05-2025----------------------------------------------------------------------------------- --}}
