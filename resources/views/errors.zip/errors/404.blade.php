



<style>
    body{
        background:url('https://ivoirrapid.ci/asset/logo.png');
        background-repeat: no-repeat;
        background-attachment: fixed;

    }

</style>

@extends('layouts.app')

@section('content')
<div class="container text-center">
    <h1 class="display-4 text-danger">Oups ! Page introuvable 😢</h1>
    <p>La page que vous recherchez n'existe pas ou a été déplacée.</p>
    <a href="{{ url('/') }}" class="btn btn-primary">Retour à l'accueil</a>
</div>
@endsection
